import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const documentPrompts: Record<string, string> = {
  "parecer-contabil": `Você é um contador especialista. Elabore um Parecer Contábil profissional e técnico com a seguinte estrutura:
1. IDENTIFICAÇÃO DO CLIENTE E PERÍODO
2. OBJETIVO DO PARECER
3. ESCOPO E METODOLOGIA
4. ANÁLISE E FUNDAMENTAÇÃO TÉCNICA
5. CONCLUSÃO E PARECER
6. LOCAL, DATA E ASSINATURA

REGRAS DE FORMATAÇÃO OBRIGATÓRIAS:
- NÃO use asteriscos (**) para negrito ou formatação markdown
- Use apenas texto simples e limpo
- Títulos de seção devem ser apenas o número e o texto (ex: "1. IDENTIFICAÇÃO")
- Organize dados tabulares de forma clara com alinhamento visual
- Separe claramente cada seção com uma linha em branco
- Use linguagem técnica, cite normas contábeis (CPC, NBC) quando aplicável
- Seja objetivo e conclusivo`,
  
  "parecer-fiscal": `Você é um especialista tributário. Elabore um Parecer Fiscal profissional com a seguinte estrutura:
1. IDENTIFICAÇÃO DO CONTRIBUINTE
2. OBJETO DA CONSULTA
3. FUNDAMENTAÇÃO LEGAL
4. ANÁLISE TÉCNICA
5. CONCLUSÃO E RECOMENDAÇÕES
6. LOCAL, DATA E ASSINATURA

REGRAS DE FORMATAÇÃO OBRIGATÓRIAS:
- NÃO use asteriscos (**) para negrito ou formatação markdown
- Use apenas texto simples e limpo
- Títulos de seção devem ser apenas o número e o texto
- Cite legislação tributária específica (CTN, RIR, ICMS, ISS, etc)
- Seja preciso e fundamentado`,
  
  "memorando": `Você é um contador sênior. Elabore um Memorando Técnico interno com a seguinte estrutura:
1. PARA / DE / DATA / ASSUNTO
2. CONTEXTUALIZAÇÃO
3. ANÁLISE TÉCNICA
4. PONTOS DE ATENÇÃO
5. RECOMENDAÇÕES
6. PRÓXIMOS PASSOS

REGRAS DE FORMATAÇÃO OBRIGATÓRIAS:
- NÃO use asteriscos (**) para negrito ou formatação markdown
- Use apenas texto simples e limpo
- Seja direto, objetivo e técnico`,
  
  "relatorio": `Você é um controller financeiro. Elabore um Relatório Gerencial executivo com a seguinte estrutura:
1. RESUMO EXECUTIVO
2. INDICADORES CHAVE (calcule e apresente indicadores como Margem Bruta, Margem EBITDA, Margem Líquida, ROE, etc.)
3. ANÁLISE DE DESEMPENHO (analise receitas, custos, despesas, variações)
4. PONTOS DE ATENÇÃO (identifique problemas e riscos)
5. RECOMENDAÇÕES ESTRATÉGICAS
6. CONCLUSÃO

REGRAS DE FORMATAÇÃO OBRIGATÓRIAS:
- NÃO use asteriscos (**) para negrito ou formatação markdown
- Use apenas texto simples e limpo
- Para dados numéricos, apresente em formato de lista ou tabela simples
- Separe cada indicador em sua própria linha com formato: "Indicador: valor"
- Use linguagem clara para gestores, inclua métricas calculadas e insights acionáveis`,
  
  "defesa": `Você é um advogado tributarista e contador. Elabore uma Defesa à Fiscalização com a seguinte estrutura:
1. QUALIFICAÇÃO DO AUTUADO
2. SÍNTESE DA AUTUAÇÃO
3. DA TEMPESTIVIDADE
4. PRELIMINARES (se aplicável)
5. DO MÉRITO - FUNDAMENTAÇÃO DA DEFESA
6. DOS PEDIDOS
7. LOCAL, DATA E ASSINATURA

REGRAS DE FORMATAÇÃO OBRIGATÓRIAS:
- NÃO use asteriscos (**) para negrito ou formatação markdown
- Use apenas texto simples e limpo
- Cite legislação, jurisprudência e doutrina
- Seja técnico e persuasivo`,
  
  "email": `Você é um contador que precisa comunicar assuntos técnicos de forma clara. Elabore um E-mail Técnico profissional com:
1. ASSUNTO (claro e direto)
2. SAUDAÇÃO
3. CONTEXTO BREVE
4. INFORMAÇÃO PRINCIPAL / SOLICITAÇÃO
5. DETALHES TÉCNICOS (se necessário)
6. PRÓXIMOS PASSOS / AÇÃO ESPERADA
7. DESPEDIDA PROFISSIONAL

REGRAS DE FORMATAÇÃO OBRIGATÓRIAS:
- NÃO use asteriscos (**) para negrito ou formatação markdown
- Use apenas texto simples e limpo
- Seja claro, cordial e objetivo`
};

const fileAnalysisPrompts: Record<string, string> = {
  "parecer-contabil": `Analise os dados contábeis fornecidos no arquivo e utilize-os para fundamentar o parecer. 
Identifique saldos, movimentações, inconsistências e pontos relevantes para embasar sua análise técnica.
EXTRAIA do arquivo: Nome da empresa, CNPJ e Período de referência usando as regras de extração abaixo.`,
  
  "parecer-fiscal": `Analise os dados fiscais/tributários fornecidos no arquivo. 
Identifique tributos, bases de cálculo, alíquotas, créditos e débitos para fundamentar o parecer fiscal.
EXTRAIA do arquivo: Nome da empresa, CNPJ e Período de referência usando as regras de extração abaixo.`,
  
  "memorando": `Analise os dados do arquivo e extraia as informações relevantes para o memorando técnico.
Identifique pontos de atenção e informações que devem ser comunicadas internamente.
EXTRAIA do arquivo: Nome da empresa, CNPJ e Período de referência usando as regras de extração abaixo.`,
  
  "relatorio": `Analise detalhadamente os dados financeiros do arquivo (DRE, Balanço, fluxo de caixa, etc).
CALCULE os indicadores: Margem Bruta = (Lucro Bruto / Receita) x 100, Margem EBITDA, Margem Líquida, variações percentuais entre períodos.
IDENTIFIQUE tendências, pontos de atenção e oportunidades de melhoria baseados nos números reais.
EXTRAIA do arquivo: Nome da empresa, CNPJ e Período de referência usando as regras de extração abaixo.`,
  
  "defesa": `Analise os dados do arquivo que servirão como prova ou fundamento para a defesa.
Identifique elementos que possam contestar a autuação ou demonstrar a regularidade fiscal.
EXTRAIA do arquivo: Nome da empresa, CNPJ e Período de referência usando as regras de extração abaixo.`,
  
  "email": `Analise os dados do arquivo e extraia as informações principais que devem ser comunicadas no e-mail.
Resuma os pontos-chave de forma clara e objetiva.
EXTRAIA do arquivo: Nome da empresa, CNPJ e Período de referência usando as regras de extração abaixo.`
};

interface FileData {
  fileName: string;
  content: string;
  companyType: 'matriz' | 'filial';
  companyName?: string;
  cnpj?: string;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { documentType, cidadeUF, observations, files } = await req.json();
    
    console.log('Generating document:', { documentType, cidadeUF, filesCount: files?.length || 0 });

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    const baseSystemPrompt = documentPrompts[documentType] || documentPrompts["parecer-contabil"];
    const fileAnalysisInstruction = fileAnalysisPrompts[documentType] || fileAnalysisPrompts["relatorio"];
    
    let systemPrompt = baseSystemPrompt;
    let userPrompt = '';

    // If files are provided, include them in the analysis
    if (files && files.length > 0) {
      const hasMultipleCompanies = files.length > 1;
      
      systemPrompt = `${baseSystemPrompt}

INSTRUÇÕES ADICIONAIS PARA ANÁLISE DO(S) ARQUIVO(S):
${fileAnalysisInstruction}

REGRAS DE EXTRAÇÃO DE DADOS (MUITO IMPORTANTE):
1. CNPJ: Busque no arquivo por padrões no formato XX.XXX.XXX/XXXX-XX ou XXXXXXXXXXXXXXX (14 dígitos)
   - Procure próximo a palavras como: "CNPJ", "CNPJ:", "CNPJ/MF", "Inscrito no CNPJ"
2. NOME DA EMPRESA: Busque por:
   - Campo "Empresa:", "Razão Social:", "Nome:", "Denominação:"
   - Se o nome não estiver na mesma linha, estará na linha ou coluna seguinte
   - Geralmente aparece no cabeçalho do documento ou próximo ao CNPJ
3. PERÍODO: Busque por datas, meses/anos de referência, "Período:", "Competência:", "Ref:"

Se não encontrar algum dado, indique claramente "[Nome/CNPJ/Período não identificado no arquivo]"

REGRAS DE FORMATAÇÃO OBRIGATÓRIAS:
- NÃO use asteriscos (**) para negrito ou formatação markdown
- Use apenas texto simples e limpo
- Títulos de seção devem ser apenas o número e o texto (ex: "1. IDENTIFICAÇÃO")
- O texto deve ser escrito para ser JUSTIFICADO (alinhamento nas duas margens)
- Parágrafos devem ser completos e bem estruturados
- Use os dados REAIS extraídos dos arquivos
${hasMultipleCompanies ? `
MÚLTIPLAS EMPRESAS - ESTRUTURA OBRIGATÓRIA:

Para CADA empresa/arquivo, você DEVE incluir uma seção completa:
"[Nº]. ANÁLISE E FUNDAMENTAÇÃO TÉCNICA - [NOME DA EMPRESA] ([MATRIZ/FILIAL])"
Contendo:
- CNPJ: [extraído do arquivo]
- Período: [extraído do arquivo]
- Detalhes da DRE/Balanço (todos os valores encontrados)
- Indicadores calculados (Margem Bruta, Margem Líquida, etc.)
- Pontos de atenção específicos

APÓS analisar todas as empresas individualmente, inclua:
"[Nº]. ANÁLISE CONSOLIDADA"
Com a soma de todos os valores e indicadores consolidados do grupo.` : `
ESTRUTURA OBRIGATÓRIA:
Você DEVE incluir uma seção detalhada de "ANÁLISE E FUNDAMENTAÇÃO TÉCNICA" contendo:
- Todos os dados numéricos encontrados no arquivo (Receita, Custos, Despesas, Lucro, etc.)
- Indicadores calculados (Margem Bruta, Margem Líquida, variações, etc.)
- Análise crítica dos números apresentados
- Pontos de atenção identificados`}

IMPORTANTE: 
- Baseie sua análise nos dados REAIS fornecidos nos arquivos
- Cite números, valores e informações específicas do documento
- NUNCA use ** ou * para formatação
- Organize os dados de forma clara e visualmente estruturada
- Apresente valores monetários separados por linha para facilitar leitura`;

      let filesContent = '';
      for (const file of files as FileData[]) {
        filesContent += `
=== ARQUIVO: ${file.fileName} (${file.companyType === 'matriz' ? 'MATRIZ' : 'FILIAL'}) ===
${file.companyName ? `Empresa informada: ${file.companyName}` : ''}
${file.cnpj ? `CNPJ informado: ${file.cnpj}` : ''}
---
${file.content}
---

`;
      }

      userPrompt = `
Local: ${cidadeUF || "[Cidade/UF]"}
Observações/Contexto Adicional: ${observations || "Nenhuma observação adicional"}

DADOS DOS ARQUIVOS IMPORTADOS:
${filesContent}

Por favor, elabore o documento completo seguindo a estrutura indicada:
1. EXTRAIA Nome da Empresa, CNPJ e Período dos dados dos arquivos
2. UTILIZE OS DADOS REAIS para fundamentar sua análise
3. Cite valores e informações específicas extraídos dos documentos
4. NÃO use formatação markdown (**, ##, etc.)
${hasMultipleCompanies ? '5. Apresente análise individual de cada empresa E análise consolidada' : ''}
`;
    } else {
      userPrompt = `
Local: ${cidadeUF || "[Cidade/UF]"}
Observações/Contexto Adicional: ${observations || "Nenhuma observação adicional"}

Por favor, elabore o documento completo seguindo a estrutura indicada.
Nota: Nenhum arquivo foi importado. Use dados ilustrativos onde necessário, indicando claramente que são exemplos.
`;
    }

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: 'Limite de requisições excedido. Tente novamente em alguns segundos.' }), {
          status: 429,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: 'Créditos de IA esgotados. Adicione créditos à sua conta.' }), {
          status: 402,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      const errorText = await response.text();
      console.error('AI gateway error:', response.status, errorText);
      throw new Error('Erro ao gerar documento');
    }

    const data = await response.json();
    let generatedContent = data.choices[0].message.content;
    
    // Clean up any remaining markdown formatting
    generatedContent = generatedContent
      .replace(/\*\*/g, '') // Remove **
      .replace(/\*([^*]+)\*/g, '$1') // Remove *text*
      .replace(/^#{1,6}\s+/gm, '') // Remove # headers
      .replace(/`([^`]+)`/g, '$1'); // Remove `code`

    console.log('Document generated successfully');

    return new Response(JSON.stringify({ 
      content: generatedContent,
      documentType,
      cidadeUF
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error generating document:', error);
    const errorMessage = error instanceof Error ? error.message : 'Erro ao gerar documento';
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
