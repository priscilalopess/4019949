import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const routinePrompts: Record<string, string> = {
  "fechamento-contabil": `Você é um contador especialista em fechamento contábil. Analise o arquivo fornecido e:
1. Identifique inconsistências ou erros
2. Verifique se os saldos estão corretos
3. Liste os ajustes necessários
4. Forneça recomendações para o fechamento
Seja técnico e detalhado.`,
  
  "analise-dre": `Você é um analista financeiro. Analise a DRE (Demonstração do Resultado do Exercício) e:
1. Analise a evolução das receitas e despesas
2. Calcule e interprete os principais indicadores (margem bruta, EBITDA, margem líquida)
3. Identifique pontos de atenção
4. Forneça insights estratégicos
Seja analítico e orientado a decisões.`,
  
  "revisao-fiscal": `Você é um especialista tributário. Analise os dados fiscais e:
1. Verifique a conformidade com a legislação
2. Identifique possíveis riscos tributários
3. Sugira oportunidades de economia fiscal
4. Liste as obrigações acessórias relacionadas
Cite a legislação aplicável.`,
  
  "auditoria": `Você é um auditor independente. Analise o documento e:
1. Identifique pontos de auditoria
2. Verifique a conformidade com normas (NBC TA)
3. Liste as evidências encontradas
4. Faça recomendações de controle interno
Seja criterioso e objetivo.`,
  
  "default": `Você é um consultor contábil e financeiro experiente. Analise o arquivo fornecido e:
1. Resuma o conteúdo principal
2. Identifique pontos relevantes
3. Liste pendências ou ações necessárias
4. Forneça recomendações profissionais
Seja claro e técnico.`
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { fileContent, fileName, fileType, routineType, routineStep } = await req.json();
    
    console.log('Analyzing file:', { fileName, fileType, routineType, routineStep });

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    const systemPrompt = routinePrompts[routineType] || routinePrompts["default"];
    
    const userPrompt = `
Arquivo: ${fileName}
Tipo: ${fileType}
Etapa da Rotina: ${routineStep || "Análise geral"}

Conteúdo do arquivo (texto extraído):
${fileContent}

Por favor, realize a análise conforme as instruções do sistema.
`;

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: 'Limite de requisições excedido. Tente novamente em alguns segundos.' }), {
          status: 429,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: 'Créditos de IA esgotados. Adicione créditos à sua conta.' }), {
          status: 402,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      const errorText = await response.text();
      console.error('AI gateway error:', response.status, errorText);
      throw new Error('Erro ao analisar arquivo');
    }

    const data = await response.json();
    const analysis = data.choices[0].message.content;

    console.log('File analysis completed successfully');

    return new Response(JSON.stringify({ 
      analysis,
      fileName,
      fileType
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error analyzing file:', error);
    const errorMessage = error instanceof Error ? error.message : 'Erro ao analisar arquivo';
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
