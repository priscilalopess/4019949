-- Create storage bucket for routine files (Excel, PDF, Word)
INSERT INTO storage.buckets (id, name, public) VALUES ('routine-files', 'routine-files', false);

-- Create RLS policies for routine-files bucket
CREATE POLICY "Users can upload routine files"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'routine-files');

CREATE POLICY "Users can view routine files"
ON storage.objects FOR SELECT
USING (bucket_id = 'routine-files');

CREATE POLICY "Users can delete routine files"
ON storage.objects FOR DELETE
USING (bucket_id = 'routine-files');

-- Create table for generated documents
CREATE TABLE public.generated_documents (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  document_type TEXT NOT NULL,
  client_name TEXT NOT NULL,
  period TEXT,
  observations TEXT,
  content TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.generated_documents ENABLE ROW LEVEL SECURITY;

-- Public access for now (no auth yet)
CREATE POLICY "Anyone can insert documents"
ON public.generated_documents FOR INSERT
WITH CHECK (true);

CREATE POLICY "Anyone can view documents"
ON public.generated_documents FOR SELECT
USING (true);

-- Create table for uploaded files in routines
CREATE TABLE public.routine_files (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  routine_id TEXT NOT NULL,
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_type TEXT NOT NULL,
  file_size INTEGER NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.routine_files ENABLE ROW LEVEL SECURITY;

-- Public access for now
CREATE POLICY "Anyone can upload routine files"
ON public.routine_files FOR INSERT
WITH CHECK (true);

CREATE POLICY "Anyone can view routine files"
ON public.routine_files FOR SELECT
USING (true);

CREATE POLICY "Anyone can delete routine files"
ON public.routine_files FOR DELETE
USING (true);