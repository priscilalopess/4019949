import { useState, useRef } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { ArrowLeft, ChevronRight, CheckCircle2, Circle, Play, RotateCcw, Upload, FileText, X, Loader2, FileSpreadsheet, File } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

type StepStatus = "done" | "current" | "pending";

interface Step {
  id: string;
  title: string;
  status: StepStatus;
}

interface UploadedFile {
  id: string;
  name: string;
  type: string;
  size: number;
  content?: string;
  analysis?: string;
  isAnalyzing?: boolean;
}

interface RoutineData {
  title: string;
  description: string;
  routineType: string;
  steps: Step[];
  quickAccess: { id: string; title: string; action: string }[];
}

const initialRoutinesData: Record<string, RoutineData> = {
  "1": {
    title: "Fechamento Contábil",
    description: "Processo completo de fechamento mensal",
    routineType: "fechamento-contabil",
    steps: [
      { id: "1", title: "Coleta de Dados", status: "pending" },
      { id: "2", title: "Conciliações", status: "pending" },
      { id: "3", title: "Conferências", status: "pending" },
      { id: "4", title: "Ajustes", status: "pending" },
      { id: "5", title: "Documento Final", status: "pending" },
    ],
    quickAccess: [
      { id: "1", title: "Checklist", action: "checklist" },
      { id: "2", title: "Modelos", action: "modelos" },
      { id: "3", title: "Documentos Gerados", action: "documentos" },
    ],
  },
  "2": {
    title: "Atendimento Fiscal",
    description: "Rotina de atendimento e revisão fiscal",
    routineType: "revisao-fiscal",
    steps: [
      { id: "1", title: "Análise de Documentos", status: "pending" },
      { id: "2", title: "Verificação de Conformidade", status: "pending" },
      { id: "3", title: "Elaboração de Parecer", status: "pending" },
      { id: "4", title: "Revisão Final", status: "pending" },
    ],
    quickAccess: [
      { id: "1", title: "Checklist", action: "checklist" },
      { id: "2", title: "Modelos", action: "modelos" },
    ],
  },
  "3": {
    title: "Parecer Trabalhista",
    description: "Elaboração de parecer trabalhista completo",
    routineType: "default",
    steps: [
      { id: "1", title: "Levantamento de Dados", status: "pending" },
      { id: "2", title: "Análise da Legislação", status: "pending" },
      { id: "3", title: "Elaboração do Parecer", status: "pending" },
      { id: "4", title: "Revisão e Aprovação", status: "pending" },
    ],
    quickAccess: [
      { id: "1", title: "Checklist", action: "checklist" },
      { id: "2", title: "Modelos", action: "modelos" },
    ],
  },
};

const defaultRoutine: RoutineData = {
  title: "Rotina",
  description: "Rotina profissional",
  routineType: "default",
  steps: [
    { id: "1", title: "Etapa 1", status: "pending" },
    { id: "2", title: "Etapa 2", status: "pending" },
    { id: "3", title: "Etapa 3", status: "pending" },
  ],
  quickAccess: [
    { id: "1", title: "Checklist", action: "checklist" },
    { id: "2", title: "Modelos", action: "modelos" },
  ],
};

const RotinaDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const initialRoutine = initialRoutinesData[id || ""] || defaultRoutine;
  const [steps, setSteps] = useState<Step[]>(initialRoutine.steps);
  const [isStarted, setIsStarted] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [selectedAnalysis, setSelectedAnalysis] = useState<string | null>(null);

  const routine = {
    ...initialRoutine,
    steps,
  };

  const getStatusIcon = (status: StepStatus) => {
    switch (status) {
      case "done":
        return <CheckCircle2 className="h-5 w-5 text-success" strokeWidth={1.5} />;
      case "current":
        return <Circle className="h-5 w-5 text-accent fill-accent/20" strokeWidth={1.5} />;
      default:
        return <Circle className="h-5 w-5 text-muted-foreground/40" strokeWidth={1.5} />;
    }
  };

  const getStatusLabel = (status: StepStatus) => {
    switch (status) {
      case "done":
        return "Concluído";
      case "current":
        return "Em andamento";
      default:
        return "Em aberto";
    }
  };

  const getFileIcon = (type: string) => {
    if (type.includes('spreadsheet') || type.includes('excel') || type.includes('csv')) {
      return <FileSpreadsheet className="h-5 w-5 text-success" />;
    }
    if (type.includes('pdf')) {
      return <FileText className="h-5 w-5 text-destructive" />;
    }
    return <File className="h-5 w-5 text-primary" />;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    const allowedTypes = [
      'application/pdf',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'text/csv',
      'text/plain'
    ];

    for (const file of Array.from(files)) {
      if (!allowedTypes.includes(file.type) && !file.name.endsWith('.csv')) {
        toast({
          title: "Tipo de arquivo não suportado",
          description: `${file.name} não é um arquivo suportado. Use PDF, Excel, Word ou CSV.`,
          variant: "destructive",
        });
        continue;
      }

      const newFile: UploadedFile = {
        id: crypto.randomUUID(),
        name: file.name,
        type: file.type,
        size: file.size,
      };

      setUploadedFiles(prev => [...prev, newFile]);

      // Read file content for text-based files
      if (file.type === 'text/plain' || file.type === 'text/csv' || file.name.endsWith('.csv')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const content = e.target?.result as string;
          setUploadedFiles(prev => 
            prev.map(f => f.id === newFile.id ? { ...f, content } : f)
          );
        };
        reader.readAsText(file);
      }

      toast({
        title: "Arquivo carregado",
        description: `${file.name} foi adicionado à rotina.`,
      });
    }

    // Reset input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleAnalyzeFile = async (fileId: string) => {
    const file = uploadedFiles.find(f => f.id === fileId);
    if (!file) return;

    if (!file.content && file.type !== 'text/plain' && file.type !== 'text/csv') {
      toast({
        title: "Análise limitada",
        description: "Apenas arquivos de texto/CSV podem ser analisados diretamente. PDFs e Excel precisam de extração prévia.",
        variant: "destructive",
      });
      return;
    }

    setUploadedFiles(prev => 
      prev.map(f => f.id === fileId ? { ...f, isAnalyzing: true } : f)
    );

    try {
      const currentStep = steps.find(s => s.status === "current");
      
      const { data, error } = await supabase.functions.invoke('analyze-file', {
        body: {
          fileContent: file.content || `[Conteúdo do arquivo ${file.name} - tipo: ${file.type}]`,
          fileName: file.name,
          fileType: file.type,
          routineType: routine.routineType,
          routineStep: currentStep?.title || "Análise geral",
        }
      });

      if (error) throw error;

      if (data.error) {
        toast({
          title: "Erro na análise",
          description: data.error,
          variant: "destructive",
        });
        return;
      }

      setUploadedFiles(prev => 
        prev.map(f => f.id === fileId ? { ...f, analysis: data.analysis, isAnalyzing: false } : f)
      );

      toast({
        title: "Análise concluída!",
        description: `${file.name} foi analisado com sucesso.`,
      });

    } catch (error) {
      console.error('Error analyzing file:', error);
      setUploadedFiles(prev => 
        prev.map(f => f.id === fileId ? { ...f, isAnalyzing: false } : f)
      );
      toast({
        title: "Erro na análise",
        description: "Ocorreu um erro ao analisar o arquivo. Tente novamente.",
        variant: "destructive",
      });
    }
  };

  const handleRemoveFile = (fileId: string) => {
    setUploadedFiles(prev => prev.filter(f => f.id !== fileId));
    if (selectedAnalysis === fileId) {
      setSelectedAnalysis(null);
    }
    toast({
      title: "Arquivo removido",
      description: "O arquivo foi removido da rotina.",
    });
  };

  const handleStartRoutine = () => {
    if (!isStarted) {
      setSteps(prev => prev.map((step, index) => ({
        ...step,
        status: index === 0 ? "current" : "pending"
      })));
      setIsStarted(true);
      toast({
        title: "Rotina iniciada!",
        description: `${routine.title} foi iniciada com sucesso.`,
      });
    }
  };

  const handleStepClick = (stepId: string, currentStatus: StepStatus) => {
    if (!isStarted) {
      toast({
        title: "Rotina não iniciada",
        description: "Clique em 'Iniciar Rotina' para começar.",
        variant: "destructive",
      });
      return;
    }

    const stepIndex = steps.findIndex(s => s.id === stepId);
    
    if (currentStatus === "current") {
      setSteps(prev => prev.map((step, index) => {
        if (index === stepIndex) {
          return { ...step, status: "done" };
        }
        if (index === stepIndex + 1) {
          return { ...step, status: "current" };
        }
        return step;
      }));

      if (stepIndex === steps.length - 1) {
        toast({
          title: "Rotina concluída!",
          description: `${routine.title} foi finalizada com sucesso.`,
        });
      } else {
        toast({
          title: "Etapa concluída!",
          description: `${steps[stepIndex].title} foi marcada como concluída.`,
        });
      }
    } else if (currentStatus === "done") {
      toast({
        title: "Etapa já concluída",
        description: "Esta etapa já foi finalizada.",
      });
    } else {
      toast({
        title: "Etapa bloqueada",
        description: "Complete as etapas anteriores primeiro.",
      });
    }
  };

  const handleResetRoutine = () => {
    setSteps(initialRoutine.steps);
    setIsStarted(false);
    setUploadedFiles([]);
    setSelectedAnalysis(null);
    toast({
      title: "Rotina reiniciada",
      description: "Todas as etapas foram resetadas.",
    });
  };

  const handleQuickAccess = (action: string) => {
    switch (action) {
      case "checklist":
        toast({
          title: "Checklist",
          description: "Abrindo checklist da rotina...",
        });
        break;
      case "modelos":
        navigate("/biblioteca");
        break;
      case "documentos":
        navigate("/documentos");
        break;
      default:
        break;
    }
  };

  const allDone = steps.every(s => s.status === "done");

  return (
    <div className="container py-6 space-y-6 animate-fade-in">
      {/* Back Button */}
      <Link 
        to="/rotinas" 
        className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        <ArrowLeft className="h-4 w-4" strokeWidth={1.5} />
        Voltar
      </Link>

      {/* Page Title */}
      <div>
        <h1 className="font-display text-2xl font-semibold text-foreground">{routine.title}</h1>
        <p className="text-sm text-muted-foreground mt-1">{routine.description}</p>
      </div>

      {/* File Upload Section */}
      <section>
        <h2 className="text-sm font-medium text-muted-foreground mb-3">Arquivos para Análise</h2>
        <Card className="shadow-card">
          <CardContent className="p-4 space-y-4">
            {/* Upload Area */}
            <div 
              className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-primary/50 transition-colors cursor-pointer"
              onClick={() => fileInputRef.current?.click()}
            >
              <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" strokeWidth={1.5} />
              <p className="text-sm font-medium text-foreground">Clique para enviar arquivos</p>
              <p className="text-xs text-muted-foreground mt-1">PDF, Excel, Word ou CSV</p>
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.xls,.xlsx,.doc,.docx,.csv,.txt"
                multiple
                className="hidden"
                onChange={handleFileUpload}
              />
            </div>

            {/* Uploaded Files List */}
            {uploadedFiles.length > 0 && (
              <div className="space-y-2">
                {uploadedFiles.map((file) => (
                  <div key={file.id} className="space-y-2">
                    <div className="flex items-center gap-3 p-3 bg-muted/30 rounded-lg">
                      {getFileIcon(file.type)}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{file.name}</p>
                        <p className="text-xs text-muted-foreground">{formatFileSize(file.size)}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        {file.isAnalyzing ? (
                          <Loader2 className="h-4 w-4 animate-spin text-primary" />
                        ) : file.analysis ? (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-xs"
                            onClick={() => setSelectedAnalysis(selectedAnalysis === file.id ? null : file.id)}
                          >
                            {selectedAnalysis === file.id ? "Ocultar" : "Ver Análise"}
                          </Button>
                        ) : (
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-xs"
                            onClick={() => handleAnalyzeFile(file.id)}
                          >
                            Analisar com IA
                          </Button>
                        )}
                        <button 
                          onClick={() => handleRemoveFile(file.id)}
                          className="text-muted-foreground hover:text-destructive transition-colors"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                    
                    {/* Analysis Result */}
                    {selectedAnalysis === file.id && file.analysis && (
                      <div className="p-4 bg-primary/5 rounded-lg border border-primary/20 animate-fade-in">
                        <h4 className="text-sm font-medium text-foreground mb-2">Análise do Arquivo</h4>
                        <div className="text-sm text-muted-foreground whitespace-pre-wrap max-h-64 overflow-y-auto">
                          {file.analysis}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </section>

      {/* Steps */}
      <section>
        <h2 className="text-sm font-medium text-muted-foreground mb-3">Etapas</h2>
        <Card className="shadow-card">
          <CardContent className="p-0 divide-y divide-border">
            {routine.steps.map((step, index) => (
              <button 
                key={step.id}
                onClick={() => handleStepClick(step.id, step.status)}
                className={cn(
                  "w-full flex items-center gap-4 p-4 transition-colors text-left",
                  step.status === "current" && "bg-accent/5 hover:bg-accent/10",
                  step.status === "pending" && "hover:bg-muted/50",
                  step.status === "done" && "hover:bg-success/5"
                )}
              >
                {getStatusIcon(step.status)}
                <div className="flex-1">
                  <span className="text-sm font-medium text-foreground">
                    {index + 1}) {step.title}
                  </span>
                </div>
                <span className={cn(
                  "text-xs px-2 py-1 rounded-full",
                  step.status === "done" && "bg-success/10 text-success",
                  step.status === "current" && "bg-accent/10 text-accent",
                  step.status === "pending" && "bg-muted text-muted-foreground"
                )}>
                  {getStatusLabel(step.status)}
                </span>
              </button>
            ))}
          </CardContent>
        </Card>
      </section>

      {/* Action Buttons */}
      <div className="flex gap-3">
        {!isStarted ? (
          <Button 
            className="flex-1 h-12 text-base font-medium gradient-premium"
            onClick={handleStartRoutine}
          >
            <Play className="h-4 w-4 mr-2" strokeWidth={1.5} />
            Iniciar Rotina
          </Button>
        ) : allDone ? (
          <Button 
            className="flex-1 h-12 text-base font-medium"
            variant="outline"
            onClick={handleResetRoutine}
          >
            <RotateCcw className="h-4 w-4 mr-2" strokeWidth={1.5} />
            Reiniciar Rotina
          </Button>
        ) : (
          <>
            <Button 
              className="flex-1 h-12 text-base font-medium gradient-premium"
              onClick={() => {
                const currentStep = steps.find(s => s.status === "current");
                if (currentStep) handleStepClick(currentStep.id, "current");
              }}
            >
              Concluir Etapa Atual
            </Button>
            <Button 
              variant="outline"
              size="icon"
              className="h-12 w-12"
              onClick={handleResetRoutine}
            >
              <RotateCcw className="h-4 w-4" strokeWidth={1.5} />
            </Button>
          </>
        )}
      </div>

      {/* Quick Access */}
      <section>
        <h2 className="text-sm font-medium text-muted-foreground mb-3">Acessos Rápidos</h2>
        <Card className="shadow-card">
          <CardContent className="p-0 divide-y divide-border">
            {routine.quickAccess.map((item) => (
              <button 
                key={item.id}
                onClick={() => handleQuickAccess(item.action)}
                className="w-full flex items-center justify-between p-4 hover:bg-muted/50 transition-colors"
              >
                <span className="text-sm font-medium text-foreground">{item.title}</span>
                <ChevronRight className="h-4 w-4 text-muted-foreground" strokeWidth={1.5} />
              </button>
            ))}
          </CardContent>
        </Card>
      </section>
    </div>
  );
};

export default RotinaDetail;
