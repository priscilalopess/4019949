import { useState, useRef } from "react";
import { ChevronRight, FileText, Loader2, CheckCircle2, Download, FileDown, Upload, X, File, Plus, Building2, Building, FileType } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { jsPDF } from "jspdf";
import * as XLSX from "xlsx";
import { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, BorderStyle } from "docx";
import { saveAs } from "file-saver";
const documentTypes = [
  { id: "parecer-contabil", title: "Parecer Contábil", icon: FileText, description: "Importe balancetes, razões ou demonstrações" },
  { id: "parecer-fiscal", title: "Parecer Fiscal", icon: FileText, description: "Importe arquivos fiscais, SPED, XMLs" },
  { id: "memorando", title: "Memorando Técnico", icon: FileText, description: "Importe documentos de referência" },
  { id: "relatorio", title: "Relatório Gerencial", icon: FileText, description: "Importe DRE, Balanço, indicadores" },
  { id: "defesa", title: "Defesa à Fiscalização", icon: FileText, description: "Importe autos de infração, notificações" },
  { id: "email", title: "E-mail Técnico", icon: FileText, description: "Importe dados para comunicação" },
];

interface GeneratedDocument {
  title: string;
  content: string;
  cidadeUF: string;
  observations: string;
  documentType: string;
}

interface UploadedFile {
  id: string;
  file: File;
  content: string;
  companyType: 'matriz' | 'filial';
  companyName?: string;
  cnpj?: string;
}

const Documentos = () => {
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    cidadeUF: "",
    observacoes: "",
  });
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedDoc, setGeneratedDoc] = useState<GeneratedDocument | null>(null);
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [isProcessingFile, setIsProcessingFile] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const getDocumentTitle = (id: string) => {
    return documentTypes.find(d => d.id === id)?.title || "Documento";
  };

  const extractTextFromExcel = async (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = e.target?.result;
          const workbook = XLSX.read(data, { type: 'array' });
          
          let allContent: string[] = [];
          
          // Process all sheets
          workbook.SheetNames.forEach((sheetName) => {
            const worksheet = workbook.Sheets[sheetName];
            
            // Convert to JSON to get structured data
            const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: '' }) as (string | number)[][];
            
            if (jsonData.length > 0) {
              allContent.push(`=== ${sheetName} ===`);
              
              jsonData.forEach((row) => {
                // Filter out empty cells and join with tab for structure
                const filteredRow = row.filter(cell => cell !== '' && cell !== null && cell !== undefined);
                if (filteredRow.length > 0) {
                  // Format row as key-value pairs if possible, or as CSV
                  const rowText = filteredRow.map(cell => {
                    if (typeof cell === 'number') {
                      // Format numbers with Brazilian locale
                      return cell.toLocaleString('pt-BR');
                    }
                    return String(cell);
                  }).join(' | ');
                  allContent.push(rowText);
                }
              });
              
              allContent.push(''); // Empty line between sheets
            }
          });
          
          const content = allContent.join('\n');
          console.log('Excel content extracted:', content.substring(0, 500) + '...');
          resolve(content || `[Arquivo Excel vazio: ${file.name}]`);
        } catch (error) {
          console.error('Error parsing Excel:', error);
          reject(error);
        }
      };
      reader.onerror = () => reject(reader.error);
      reader.readAsArrayBuffer(file);
    });
  };

  const extractTextFromFile = async (file: File): Promise<string> => {
    const fileType = file.type;
    const fileName = file.name.toLowerCase();

    // Handle Excel files with xlsx library
    if (fileName.endsWith('.xlsx') || fileName.endsWith('.xls') || 
        fileType === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
        fileType === 'application/vnd.ms-excel') {
      try {
        const content = await extractTextFromExcel(file);
        return content;
      } catch (error) {
        console.error('Failed to parse Excel:', error);
        return `[Erro ao ler arquivo Excel: ${file.name}]`;
      }
    }

    // Handle text/CSV files
    if (fileType === 'text/plain' || fileType === 'text/csv' || 
        fileName.endsWith('.txt') || fileName.endsWith('.csv')) {
      return await file.text();
    }

    // Try reading as text for other files
    try {
      const text = await file.text();
      if (text && !text.includes('\x00') && text.length > 0) {
        return text;
      }
    } catch {
      // Fall through
    }

    if (fileName.endsWith('.pdf')) {
      return `[Arquivo PDF: ${file.name}]\n\nNota: Para melhor análise de PDFs, considere converter para texto ou CSV antes de importar.`;
    }

    return `[Arquivo: ${file.name}]\n\nTipo: ${fileType || 'desconhecido'}`;
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    setIsProcessingFile(true);
    
    try {
      for (const file of Array.from(files)) {
        if (file.size > 5 * 1024 * 1024) {
          toast({
            title: "Arquivo muito grande",
            description: `${file.name} excede o limite de 5MB.`,
            variant: "destructive",
          });
          continue;
        }

        const content = await extractTextFromFile(file);
        const newFile: UploadedFile = {
          id: crypto.randomUUID(),
          file,
          content,
          companyType: uploadedFiles.length === 0 ? 'matriz' : 'filial',
        };
        
        setUploadedFiles(prev => [...prev, newFile]);
      }
      
      toast({
        title: "Arquivos importados",
        description: `${files.length} arquivo(s) carregado(s) com sucesso.`,
      });
    } catch (error) {
      console.error('Error processing files:', error);
      toast({
        title: "Erro ao processar arquivos",
        description: "Não foi possível ler o conteúdo de alguns arquivos.",
        variant: "destructive",
      });
    } finally {
      setIsProcessingFile(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const updateFileCompanyType = (fileId: string, companyType: 'matriz' | 'filial') => {
    setUploadedFiles(prev => prev.map(f => 
      f.id === fileId ? { ...f, companyType } : f
    ));
  };

  const updateFileCompanyName = (fileId: string, companyName: string) => {
    setUploadedFiles(prev => prev.map(f => 
      f.id === fileId ? { ...f, companyName } : f
    ));
  };

  const updateFileCnpj = (fileId: string, cnpj: string) => {
    setUploadedFiles(prev => prev.map(f => 
      f.id === fileId ? { ...f, cnpj } : f
    ));
  };

  const removeFile = (fileId: string) => {
    setUploadedFiles(prev => prev.filter(f => f.id !== fileId));
  };

  const handleGenerate = async () => {
    if (!selectedType) return;

    setIsGenerating(true);
    
    try {
      const filesData = uploadedFiles.map(f => ({
        fileName: f.file.name,
        content: f.content,
        companyType: f.companyType,
        companyName: f.companyName,
        cnpj: f.cnpj,
      }));

      const { data, error } = await supabase.functions.invoke('generate-document', {
        body: {
          documentType: selectedType,
          cidadeUF: formData.cidadeUF,
          observations: formData.observacoes,
          files: filesData,
        }
      });

      if (error) throw error;

      if (data.error) {
        toast({
          title: "Erro ao gerar documento",
          description: data.error,
          variant: "destructive",
        });
        return;
      }

      const docTitle = getDocumentTitle(selectedType);
      setGeneratedDoc({
        title: docTitle,
        content: data.content,
        cidadeUF: formData.cidadeUF,
        observations: formData.observacoes,
        documentType: selectedType,
      });
      
      toast({
        title: "Documento gerado!",
        description: `${docTitle} foi criado com sucesso.`,
      });
    } catch (error) {
      console.error('Error generating document:', error);
      toast({
        title: "Erro ao gerar documento",
        description: "Ocorreu um erro ao gerar o documento. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleReset = () => {
    setSelectedType(null);
    setFormData({ cidadeUF: "", observacoes: "" });
    setGeneratedDoc(null);
    setUploadedFiles([]);
  };

  // Helper function to detect if a line is a header/section title
  const isHeader = (line: string): boolean => {
    const trimmed = line.trim();
    if (!trimmed) return false;
    
    // Numbered sections (1. TITLE, 1) TITLE, I. TITLE)
    if (/^(\d+[\.\)]|[IVX]+\.)\s+[A-ZÁÀÂÃÉÈÊÍÌÎÓÒÔÕÚÙÛÇ]/i.test(trimmed)) return true;
    
    // All caps titles (but not too short or too long)
    if (trimmed === trimmed.toUpperCase() && trimmed.length > 3 && trimmed.length < 80 && /[A-Z]/.test(trimmed)) return true;
    
    // Section keywords
    const sectionKeywords = ['RESUMO', 'CONCLUSÃO', 'PARECER', 'ANÁLISE', 'FUNDAMENTAÇÃO', 'RECOMENDAÇÕES', 'OBJETIVO', 'METODOLOGIA', 'IDENTIFICAÇÃO', 'CONSOLIDADO', 'MATRIZ', 'FILIAL', 'TÉCNICA'];
    if (sectionKeywords.some(kw => trimmed.toUpperCase().includes(kw) && trimmed.length < 80)) return true;
    
    return false;
  };

  // Clean content from markdown formatting
  const cleanContent = (content: string): string => {
    return content
      .replace(/\*\*/g, '')
      .replace(/\*([^*]+)\*/g, '$1')
      .replace(/^#{1,6}\s+/gm, '')
      .replace(/`([^`]+)`/g, '$1')
      .replace(/_([^_]+)_/g, '$1');
  };

  // Format content for PDF with improved layout
  const formatPDFContent = (doc: jsPDF, lines: string[], startY: number, margin: number, maxWidth: number, pageHeight: number): number => {
    let y = startY;
    const lineHeight = 5.5;
    const paragraphSpacing = 3;
    
    for (let i = 0; i < lines.length; i++) {
      let line = lines[i].trim();
      line = cleanContent(line);
      
      if (!line) {
        y += paragraphSpacing;
        continue;
      }
      
      // Check page break
      if (y > pageHeight - 25) {
        doc.addPage();
        y = 20;
      }
      
      // Section headers (main titles)
      if (isHeader(line)) {
        y += 6;
        doc.setFontSize(11);
        doc.setFont("helvetica", "bold");
        doc.setTextColor(30, 41, 59);
        
        const wrappedHeader = doc.splitTextToSize(line, maxWidth);
        doc.text(wrappedHeader, margin, y);
        y += wrappedHeader.length * lineHeight + 4;
        continue;
      }
      
      // Sub-headers (lines ending with ":" that are short)
      if (line.endsWith(':') && line.length < 50 && !line.includes('R$')) {
        y += 3;
        doc.setFontSize(10);
        doc.setFont("helvetica", "bold");
        doc.setTextColor(51, 65, 85);
        doc.text(line, margin, y);
        y += lineHeight + 2;
        continue;
      }
      
      // Regular paragraph text - justified
      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(51, 65, 85);
      
      const wrappedLines = doc.splitTextToSize(line, maxWidth);
      
      wrappedLines.forEach((wrappedLine: string, idx: number) => {
        if (y > pageHeight - 25) {
          doc.addPage();
          y = 20;
        }
        
        // Justify all lines except the last one of each paragraph
        const isLastLine = idx === wrappedLines.length - 1;
        if (!isLastLine && wrappedLine.length > 40) {
          // Manual justify by spreading words
          const words = wrappedLine.split(' ');
          if (words.length > 1) {
            const totalWordsWidth = words.reduce((acc, word) => acc + doc.getTextWidth(word), 0);
            const totalSpaceNeeded = maxWidth - totalWordsWidth;
            const spacePerGap = totalSpaceNeeded / (words.length - 1);
            
            let xPos = margin;
            words.forEach((word, wordIdx) => {
              doc.text(word, xPos, y);
              if (wordIdx < words.length - 1) {
                xPos += doc.getTextWidth(word) + spacePerGap;
              }
            });
          } else {
            doc.text(wrappedLine, margin, y);
          }
        } else {
          doc.text(wrappedLine, margin, y);
        }
        y += lineHeight;
      });
      
      y += 1;
    }
    
    return y;
  };

  const handleDownloadPDF = () => {
    if (!generatedDoc) return;

    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      const margin = 20;
      const maxWidth = pageWidth - margin * 2;
      
      // ===== HEADER SECTION =====
      doc.setFillColor(30, 41, 59);
      doc.rect(0, 0, pageWidth, 35, 'F');
      
      // Document title
      doc.setFontSize(16);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(255, 255, 255);
      doc.text(getDocumentTitle(generatedDoc.documentType), margin, 18);
      
      // Location and date
      doc.setFontSize(9);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(203, 213, 225);
      const headerInfo = `${generatedDoc.cidadeUF || "[Cidade/UF]"}, ${new Date().toLocaleDateString('pt-BR')}`;
      doc.text(headerInfo, margin, 28);
      
      // ===== CONTENT SECTION =====
      let yPosition = 50;
      
      const contentLines = cleanContent(generatedDoc.content).split('\n');
      
      // Format and render content
      yPosition = formatPDFContent(doc, contentLines, yPosition, margin, maxWidth, pageHeight);
      
      // ===== FOOTER =====
      const totalPages = doc.internal.pages.length - 1;
      for (let i = 1; i <= totalPages; i++) {
        doc.setPage(i);
        
        doc.setDrawColor(200, 200, 200);
        doc.line(margin, pageHeight - 15, pageWidth - margin, pageHeight - 15);
        
        doc.setFontSize(8);
        doc.setFont("helvetica", "normal");
        doc.setTextColor(128, 128, 128);
        doc.text(`Gerado pelo ControllerLab`, margin, pageHeight - 8);
        doc.text(`Página ${i} de ${totalPages}`, pageWidth - margin - 22, pageHeight - 8);
      }
      
      // Save
      const fileName = `${generatedDoc.documentType}_${new Date().toISOString().split('T')[0]}.pdf`;
      doc.save(fileName);
      
      toast({
        title: "PDF baixado!",
        description: "O documento foi salvo com sucesso.",
      });
    } catch (error) {
      console.error('Error generating PDF:', error);
      toast({
        title: "Erro ao gerar PDF",
        description: "Ocorreu um erro ao gerar o PDF. Tente novamente.",
        variant: "destructive",
      });
    }
  };

  const handleDownloadWord = async () => {
    if (!generatedDoc) return;

    try {
      const content = cleanContent(generatedDoc.content);
      const lines = content.split('\n');
      
      const children: Paragraph[] = [];
      
      // Title
      children.push(
        new Paragraph({
          children: [
            new TextRun({
              text: getDocumentTitle(generatedDoc.documentType),
              bold: true,
              size: 32,
              color: "1E293B",
            }),
          ],
          spacing: { after: 200 },
        })
      );
      
      // Subtitle with location and date
      children.push(
        new Paragraph({
          children: [
            new TextRun({
              text: `${generatedDoc.cidadeUF || "[Cidade/UF]"}, ${new Date().toLocaleDateString('pt-BR')}`,
              size: 20,
              color: "64748B",
            }),
          ],
          spacing: { after: 400 },
        })
      );
      
      // Process content lines
      for (const line of lines) {
        const trimmedLine = line.trim();
        
        if (!trimmedLine) {
          children.push(new Paragraph({ text: "", spacing: { after: 100 } }));
          continue;
        }
        
        // Check if it's a header
        if (isHeader(trimmedLine)) {
          children.push(
            new Paragraph({
              children: [
                new TextRun({
                  text: trimmedLine,
                  bold: true,
                  size: 24,
                  color: "1E293B",
                }),
              ],
              spacing: { before: 300, after: 150 },
            })
          );
          continue;
        }
        
        // Sub-headers
        if (trimmedLine.endsWith(':') && trimmedLine.length < 50 && !trimmedLine.includes('R$')) {
          children.push(
            new Paragraph({
              children: [
                new TextRun({
                  text: trimmedLine,
                  bold: true,
                  size: 22,
                  color: "334155",
                }),
              ],
              spacing: { before: 200, after: 100 },
            })
          );
          continue;
        }
        
        // Regular paragraph - justified
        children.push(
          new Paragraph({
            children: [
              new TextRun({
                text: trimmedLine,
                size: 22,
                color: "334155",
              }),
            ],
            alignment: AlignmentType.JUSTIFIED,
            spacing: { after: 120 },
          })
        );
      }
      
      // Footer
      children.push(
        new Paragraph({
          children: [
            new TextRun({
              text: "────────────────────────────────────────",
              size: 16,
              color: "CBD5E1",
            }),
          ],
          spacing: { before: 400 },
        })
      );
      
      children.push(
        new Paragraph({
          children: [
            new TextRun({
              text: "Gerado pelo ControllerLab",
              size: 16,
              color: "94A3B8",
              italics: true,
            }),
          ],
        })
      );
      
      const doc = new Document({
        sections: [
          {
            properties: {
              page: {
                margin: {
                  top: 1440,
                  right: 1440,
                  bottom: 1440,
                  left: 1440,
                },
              },
            },
            children,
          },
        ],
      });
      
      const blob = await Packer.toBlob(doc);
      const fileName = `${generatedDoc.documentType}_${new Date().toISOString().split('T')[0]}.docx`;
      saveAs(blob, fileName);
      
      toast({
        title: "Word baixado!",
        description: "O documento foi salvo com sucesso.",
      });
    } catch (error) {
      console.error('Error generating Word:', error);
      toast({
        title: "Erro ao gerar Word",
        description: "Ocorreu um erro ao gerar o documento Word. Tente novamente.",
        variant: "destructive",
      });
    }
  };

  if (generatedDoc) {
    return (
      <div className="container py-6 space-y-6 animate-fade-in">
        <div>
          <h1 className="font-display text-2xl font-semibold text-foreground">Documento Criado</h1>
          <p className="text-sm text-muted-foreground mt-1">Seu documento foi gerado com sucesso</p>
        </div>

        <Card className="shadow-card">
          <CardContent className="p-6 space-y-4">
            <div className="flex justify-center">
              <div className="h-16 w-16 rounded-full bg-success/10 flex items-center justify-center">
                <CheckCircle2 className="h-8 w-8 text-success" strokeWidth={1.5} />
              </div>
            </div>
            <div className="text-center">
              <h2 className="text-lg font-semibold text-foreground">{generatedDoc.title}</h2>
              <p className="text-sm text-muted-foreground mt-1">
                {generatedDoc.cidadeUF || "[Cidade/UF]"}, {new Date().toLocaleDateString('pt-BR')}
              </p>
            </div>
            
            {/* Document Preview */}
            <div className="mt-4 p-4 bg-muted/30 rounded-lg border border-border">
              <h3 className="text-sm font-medium text-foreground mb-2 flex items-center gap-2">
                <FileText className="h-4 w-4" />
                Prévia do Documento
              </h3>
              <div className="text-sm text-muted-foreground whitespace-pre-wrap max-h-64 overflow-y-auto text-justify">
                {generatedDoc.content}
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-3">
          <div className="flex gap-3">
            <Button 
              variant="outline" 
              className="flex-1"
              onClick={handleDownloadPDF}
            >
              <Download className="h-4 w-4 mr-2" />
              Baixar PDF
            </Button>
            <Button 
              className="flex-1 gradient-premium"
              onClick={handleDownloadWord}
            >
              <FileType className="h-4 w-4 mr-2" />
              Baixar Word
            </Button>
          </div>
          <Button 
            variant="ghost" 
            className="w-full"
            onClick={handleReset}
          >
            Criar Novo Documento
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-6 space-y-6 animate-fade-in">
      {/* Page Title */}
      <div>
        <h1 className="font-display text-2xl font-semibold text-foreground">Criar Documento</h1>
        <p className="text-sm text-muted-foreground mt-1">Importe arquivos e gere documentos profissionais com IA</p>
      </div>

      {/* Document Types */}
      <section>
        <h2 className="text-sm font-medium text-muted-foreground mb-3">Tipo de Documento</h2>
        <Card className="shadow-card">
          <CardContent className="p-0 divide-y divide-border">
            {documentTypes.map((docType) => (
              <button
                key={docType.id}
                onClick={() => setSelectedType(docType.id)}
                className={cn(
                  "w-full flex items-center justify-between p-4 transition-colors text-left",
                  selectedType === docType.id 
                    ? "bg-primary/5 border-l-2 border-l-primary" 
                    : "hover:bg-muted/50"
                )}
              >
                <div className="flex-1">
                  <span className={cn(
                    "text-sm font-medium block",
                    selectedType === docType.id ? "text-primary" : "text-foreground"
                  )}>
                    {docType.title}
                  </span>
                  <span className="text-xs text-muted-foreground">{docType.description}</span>
                </div>
                <ChevronRight className={cn(
                  "h-4 w-4 flex-shrink-0",
                  selectedType === docType.id ? "text-primary" : "text-muted-foreground"
                )} strokeWidth={1.5} />
              </button>
            ))}
          </CardContent>
        </Card>
      </section>

      {/* Form Fields - Only show when type is selected */}
      {selectedType && (
        <section className="animate-fade-in space-y-4">
          {/* File Upload Section */}
          <div>
            <h2 className="text-sm font-medium text-muted-foreground mb-3">Importar Arquivos</h2>
            <Card className="shadow-card">
              <CardContent className="p-4 space-y-4">
                {/* Uploaded Files List */}
                {uploadedFiles.length > 0 && (
                  <div className="space-y-3">
                    {uploadedFiles.map((uploadedFile, index) => (
                      <div key={uploadedFile.id} className="p-3 bg-muted/30 rounded-lg border border-border space-y-3">
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                            <File className="h-5 w-5 text-primary" strokeWidth={1.5} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-foreground truncate">
                              {uploadedFile.file.name}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {(uploadedFile.file.size / 1024).toFixed(1)} KB
                            </p>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="flex-shrink-0 h-8 w-8"
                            onClick={() => removeFile(uploadedFile.id)}
                          >
                            <X className="h-4 w-4" strokeWidth={1.5} />
                          </Button>
                        </div>
                        
                        {/* Company Type Selection */}
                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <Label className="text-xs">Tipo</Label>
                            <Select 
                              value={uploadedFile.companyType} 
                              onValueChange={(value: 'matriz' | 'filial') => updateFileCompanyType(uploadedFile.id, value)}
                            >
                              <SelectTrigger className="h-9 text-xs">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="matriz">
                                  <div className="flex items-center gap-2">
                                    <Building2 className="h-3 w-3" />
                                    Matriz
                                  </div>
                                </SelectItem>
                                <SelectItem value="filial">
                                  <div className="flex items-center gap-2">
                                    <Building className="h-3 w-3" />
                                    Filial
                                  </div>
                                </SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-1">
                            <Label className="text-xs">CNPJ (opcional)</Label>
                            <Input
                              placeholder="00.000.000/0000-00"
                              value={uploadedFile.cnpj || ''}
                              onChange={(e) => updateFileCnpj(uploadedFile.id, e.target.value)}
                              className="h-9 text-xs"
                            />
                          </div>
                        </div>
                        
                        <div className="space-y-1">
                          <Label className="text-xs">Nome da Empresa (opcional)</Label>
                          <Input
                            placeholder="Nome será extraído do arquivo se não informado"
                            value={uploadedFile.companyName || ''}
                            onChange={(e) => updateFileCompanyName(uploadedFile.id, e.target.value)}
                            className="h-9 text-xs"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                
                {/* Upload Area */}
                <div 
                  className={cn(
                    "border-2 border-dashed rounded-lg p-6 text-center transition-colors cursor-pointer",
                    "hover:border-primary/50 hover:bg-primary/5",
                    isProcessingFile && "opacity-50 pointer-events-none"
                  )}
                  onClick={() => fileInputRef.current?.click()}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    className="hidden"
                    accept=".pdf,.xlsx,.xls,.csv,.txt,.doc,.docx"
                    onChange={handleFileUpload}
                    multiple
                  />
                  {isProcessingFile ? (
                    <Loader2 className="h-8 w-8 mx-auto text-primary animate-spin" />
                  ) : (
                    <div className="flex items-center justify-center gap-2">
                      <Plus className="h-5 w-5 text-muted-foreground" strokeWidth={1.5} />
                      <Upload className="h-6 w-6 text-muted-foreground" strokeWidth={1.5} />
                    </div>
                  )}
                  <p className="mt-2 text-sm font-medium text-foreground">
                    {isProcessingFile ? "Processando..." : uploadedFiles.length > 0 ? "Adicionar mais arquivos" : "Clique para importar arquivos"}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    PDF, Excel, CSV, TXT (máx. 5MB cada) - Matriz e/ou Filiais
                  </p>
                </div>
                
                {uploadedFiles.length > 1 && (
                  <p className="text-xs text-muted-foreground bg-muted/50 p-2 rounded">
                    📊 Com múltiplos arquivos, o relatório apresentará análise individual de cada empresa e uma visão consolidada.
                  </p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Form Fields */}
          <div>
            <h2 className="text-sm font-medium text-muted-foreground mb-3">Informações do Documento</h2>
            <Card className="shadow-card">
              <CardContent className="p-4 space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="cidadeUF" className="text-sm">Cidade e UF</Label>
                  <Input
                    id="cidadeUF"
                    placeholder="Ex: São Paulo - SP"
                    value={formData.cidadeUF}
                    onChange={(e) => setFormData({ ...formData, cidadeUF: e.target.value })}
                    className="bg-background"
                  />
                  <p className="text-xs text-muted-foreground">
                    Nome da empresa, CNPJ e período serão extraídos automaticamente dos arquivos importados.
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="observacoes" className="text-sm">Observações</Label>
                  <Textarea
                    id="observacoes"
                    placeholder="Informações adicionais relevantes para a elaboração do documento..."
                    value={formData.observacoes}
                    onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
                    className="bg-background min-h-[100px] resize-none"
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      )}

      {/* Generate Button */}
      <Button 
        className="w-full h-12 text-base font-medium gradient-premium"
        disabled={!selectedType || isGenerating}
        onClick={handleGenerate}
      >
        {isGenerating ? (
          <>
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            {uploadedFiles.length > 0 ? "Analisando arquivos e gerando..." : "Gerando Documento com IA..."}
          </>
        ) : (
          <>
            <FileDown className="h-4 w-4 mr-2" />
            {uploadedFiles.length > 0 
              ? `Analisar ${uploadedFiles.length} arquivo(s) e Gerar` 
              : "Gerar Documento"}
          </>
        )}
      </Button>
    </div>
  );
};

export default Documentos;
