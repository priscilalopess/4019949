import { useState } from "react";
import { Link } from "react-router-dom";
import { Search, ChevronRight } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

const categories = [
  { id: "contabil", label: "Contábil" },
  { id: "fiscal", label: "Fiscal" },
  { id: "trabalhista", label: "Trabalhista" },
  { id: "financeiro", label: "Financeiro" },
  { id: "auditoria", label: "Auditoria" },
  { id: "estrategico", label: "Estratégico" },
];

const routines = [
  { id: "1", title: "Fechamento Contábil", category: "contabil", steps: 5 },
  { id: "2", title: "Revisão Fiscal", category: "fiscal", steps: 4 },
  { id: "3", title: "Auditoria Interna", category: "auditoria", steps: 6 },
  { id: "4", title: "Planejamento Tributário", category: "fiscal", steps: 5 },
  { id: "5", title: "Relatórios Gerenciais", category: "contabil", steps: 4 },
  { id: "6", title: "Reunião com Diretoria", category: "estrategico", steps: 3 },
  { id: "7", title: "Folha de Pagamento", category: "trabalhista", steps: 5 },
  { id: "8", title: "Fluxo de Caixa", category: "financeiro", steps: 4 },
];

const Rotinas = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const filteredRoutines = routines.filter((routine) => {
    const matchesSearch = routine.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = !selectedCategory || routine.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="container py-6 space-y-6 animate-fade-in">
      {/* Page Title */}
      <div>
        <h1 className="font-display text-2xl font-semibold text-foreground">Rotinas Profissionais</h1>
        <p className="text-sm text-muted-foreground mt-1">Gerencie seus processos de trabalho</p>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" strokeWidth={1.5} />
        <Input
          type="search"
          placeholder="Buscar rotina..."
          className="pl-10 bg-card border-border"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {/* Categories */}
      <section>
        <h2 className="text-sm font-medium text-muted-foreground mb-3">Categorias</h2>
        <div className="flex flex-wrap gap-2">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(
                selectedCategory === category.id ? null : category.id
              )}
              className={cn(
                "px-3 py-1.5 rounded-full text-xs font-medium transition-colors",
                selectedCategory === category.id
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
              )}
            >
              {category.label}
            </button>
          ))}
        </div>
      </section>

      {/* Routines List */}
      <section>
        <h2 className="text-sm font-medium text-muted-foreground mb-3">
          Rotinas Disponíveis
          <span className="ml-2 text-xs text-muted-foreground/70">({filteredRoutines.length})</span>
        </h2>
        <Card className="shadow-card">
          <CardContent className="p-0 divide-y divide-border">
            {filteredRoutines.map((routine) => (
              <Link 
                key={routine.id} 
                to={`/rotinas/${routine.id}`}
                className="flex items-center justify-between p-4 hover:bg-muted/50 transition-colors"
              >
                <div>
                  <span className="text-sm font-medium text-foreground">{routine.title}</span>
                  <p className="text-xs text-muted-foreground mt-0.5">{routine.steps} etapas</p>
                </div>
                <ChevronRight className="h-4 w-4 text-muted-foreground" strokeWidth={1.5} />
              </Link>
            ))}
            {filteredRoutines.length === 0 && (
              <div className="p-8 text-center">
                <p className="text-sm text-muted-foreground">Nenhuma rotina encontrada</p>
              </div>
            )}
          </CardContent>
        </Card>
      </section>
    </div>
  );
};

export default Rotinas;