import { Link, useNavigate } from "react-router-dom";
import { 
  FileText, 
  Clock, 
  ChevronRight, 
  Plus, 
  ListTodo, 
  Library,
  Lightbulb
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

const Dashboard = () => {
  const navigate = useNavigate();
  const { toast } = useToast();

  const recentRoutines = [
    { id: "1", title: "Fechamento Contábil", status: "Em andamento" },
    { id: "2", title: "Atendimento Fiscal", status: "Pendente" },
    { id: "3", title: "Parecer Trabalhista", status: "Concluído" },
  ];

  const suggestions = [
    { id: "1", text: "Criar relatório de diretoria?", action: "relatorio" },
    { id: "2", text: "Atualizar parecer fiscal?", action: "parecer-fiscal" },
  ];

  const handleSuggestionClick = (suggestion: typeof suggestions[0]) => {
    switch (suggestion.action) {
      case "relatorio":
        toast({
          title: "Criando Relatório",
          description: "Redirecionando para criação de documento...",
        });
        navigate("/documentos");
        break;
      case "parecer-fiscal":
        toast({
          title: "Parecer Fiscal",
          description: "Abrindo parecer fiscal para atualização...",
        });
        navigate("/documentos");
        break;
      default:
        break;
    }
  };

  return (
    <div className="container py-6 space-y-6 animate-fade-in">
      {/* Page Title */}
      <div>
        <h1 className="font-display text-2xl font-semibold text-foreground">Dashboard</h1>
        <p className="text-sm text-muted-foreground mt-1">Bem-vindo ao ControllerLab</p>
      </div>

      {/* Productivity Card */}
      <Card className="shadow-card">
        <CardContent className="p-5">
          <h2 className="text-sm font-medium text-muted-foreground mb-4">Produtividade Hoje</h2>
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <FileText className="h-5 w-5 text-primary" strokeWidth={1.5} />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">04</p>
                <p className="text-xs text-muted-foreground">Documentos criados</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
                <Clock className="h-5 w-5 text-accent" strokeWidth={1.5} />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">2h40</p>
                <p className="text-xs text-muted-foreground">Tempo economizado</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Routines */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-medium text-muted-foreground">Rotinas Recentes</h2>
          <Link to="/rotinas" className="text-xs text-primary hover:underline">Ver todas</Link>
        </div>
        <Card className="shadow-card">
          <CardContent className="p-0 divide-y divide-border">
            {recentRoutines.map((routine) => (
              <Link 
                key={routine.id} 
                to={`/rotinas/${routine.id}`}
                className="flex items-center justify-between p-4 hover:bg-muted/50 transition-colors"
              >
                <span className="text-sm font-medium text-foreground">{routine.title}</span>
                <ChevronRight className="h-4 w-4 text-muted-foreground" strokeWidth={1.5} />
              </Link>
            ))}
          </CardContent>
        </Card>
      </section>

      {/* Smart Suggestions */}
      <section>
        <div className="flex items-center gap-2 mb-3">
          <Lightbulb className="h-4 w-4 text-accent" strokeWidth={1.5} />
          <h2 className="text-sm font-medium text-muted-foreground">Sugestões Inteligentes</h2>
        </div>
        <div className="space-y-2">
          {suggestions.map((suggestion) => (
            <Card 
              key={suggestion.id} 
              className="shadow-card hover:shadow-premium transition-shadow cursor-pointer"
              onClick={() => handleSuggestionClick(suggestion)}
            >
              <CardContent className="p-4 flex items-center justify-between">
                <span className="text-sm text-foreground">{suggestion.text}</span>
                <ChevronRight className="h-4 w-4 text-muted-foreground" strokeWidth={1.5} />
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Quick Access */}
      <section>
        <h2 className="text-sm font-medium text-muted-foreground mb-3">Acesso Rápido</h2>
        <div className="grid grid-cols-3 gap-3">
          <Link to="/documentos">
            <Button variant="outline" className="w-full h-auto py-4 flex flex-col gap-2">
              <Plus className="h-5 w-5" strokeWidth={1.5} />
              <span className="text-xs">Documento</span>
            </Button>
          </Link>
          <Link to="/rotinas">
            <Button variant="outline" className="w-full h-auto py-4 flex flex-col gap-2">
              <ListTodo className="h-5 w-5" strokeWidth={1.5} />
              <span className="text-xs">Rotinas</span>
            </Button>
          </Link>
          <Link to="/biblioteca">
            <Button variant="outline" className="w-full h-auto py-4 flex flex-col gap-2">
              <Library className="h-5 w-5" strokeWidth={1.5} />
              <span className="text-xs">Biblioteca</span>
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Dashboard;
