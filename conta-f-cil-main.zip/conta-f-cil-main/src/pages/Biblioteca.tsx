import { useState, useMemo } from "react";
import { Search, Copy, Check, ChevronRight, ArrowLeft, Play } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { prompts, categories } from "@/data/prompts";
import { cn } from "@/lib/utils";

const playbooks = [
  { 
    id: "1", 
    title: "Onboarding de Cliente", 
    description: "Processo completo para novos clientes", 
    steps: [
      "Coleta de documentos iniciais",
      "Análise societária",
      "Configuração fiscal",
      "Parametrização contábil",
      "Treinamento inicial",
      "Validação de processos",
      "Entrega de relatórios modelo",
      "Reunião de alinhamento final"
    ]
  },
  { 
    id: "2", 
    title: "Auditoria Trimestral", 
    description: "Checklist de auditoria completo", 
    steps: [
      "Levantamento de documentos",
      "Análise de controles internos",
      "Teste de transações",
      "Verificação de conformidade",
      "Análise de riscos",
      "Elaboração de relatório",
      "Revisão com gestão",
      "Plano de ação corretiva"
    ]
  },
  { 
    id: "3", 
    title: "Fechamento Anual", 
    description: "Roteiro para encerramento do exercício", 
    steps: [
      "Conciliação de todas as contas",
      "Revisão de provisões",
      "Ajustes de inventário",
      "Cálculo de depreciação",
      "Apuração de impostos",
      "Elaboração de demonstrações",
      "Notas explicativas",
      "Revisão final",
      "Aprovação da diretoria"
    ]
  },
];

const specialties = [
  { id: "tributario", title: "Contador Tributário", prompts: 45, description: "Especialista em planejamento e compliance tributário" },
  { id: "custos", title: "Contador de Custos", prompts: 32, description: "Análise e gestão de custos empresariais" },
  { id: "auditor", title: "Auditor Contábil", prompts: 38, description: "Auditoria interna e externa" },
  { id: "gerencial", title: "Contador Gerencial", prompts: 28, description: "Relatórios e análises gerenciais" },
  { id: "controller", title: "Controller", prompts: 35, description: "Controle e gestão financeira estratégica" },
];

type ViewMode = "list" | "playbook-detail" | "specialty-detail";

const Biblioteca = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>("list");
  const [selectedPlaybook, setSelectedPlaybook] = useState<typeof playbooks[0] | null>(null);
  const [selectedSpecialty, setSelectedSpecialty] = useState<typeof specialties[0] | null>(null);
  const { toast } = useToast();

  const filteredPrompts = useMemo(() => {
    let filtered = prompts;
    
    if (selectedSpecialty) {
      // Filter by specialty - this is a simple example, you'd want to tag prompts properly
      const specialtyKeywords: Record<string, string[]> = {
        tributario: ["tributário", "fiscal", "imposto", "tributo"],
        custos: ["custo", "margem", "preço"],
        auditor: ["auditoria", "audit", "verificação", "controle"],
        gerencial: ["gerencial", "relatório", "análise", "gestão"],
        controller: ["controller", "orçamento", "planejamento", "estratégia"],
      };
      const keywords = specialtyKeywords[selectedSpecialty.id] || [];
      filtered = prompts.filter(p => 
        keywords.some(k => 
          p.title.toLowerCase().includes(k) || 
          p.content.toLowerCase().includes(k)
        )
      );
    }
    
    if (searchTerm.trim()) {
      const searchLower = searchTerm.toLowerCase();
      filtered = filtered.filter(
        (p) =>
          p.title.toLowerCase().includes(searchLower) ||
          p.content.toLowerCase().includes(searchLower)
      );
    }
    
    return filtered.slice(0, 20);
  }, [searchTerm, selectedSpecialty]);

  const handleCopy = async (id: string, content: string) => {
    await navigator.clipboard.writeText(content);
    setCopiedId(id);
    toast({
      title: "Copiado!",
      description: "Prompt copiado para a área de transferência",
    });
    setTimeout(() => setCopiedId(null), 2000);
  };

  const getCategoryLabel = (categoryId: string) => {
    return categories.find(c => c.id === categoryId)?.title || categoryId;
  };

  const handlePlaybookClick = (playbook: typeof playbooks[0]) => {
    setSelectedPlaybook(playbook);
    setViewMode("playbook-detail");
  };

  const handleSpecialtyClick = (specialty: typeof specialties[0]) => {
    setSelectedSpecialty(specialty);
    setViewMode("specialty-detail");
  };

  const handleBack = () => {
    setViewMode("list");
    setSelectedPlaybook(null);
    setSelectedSpecialty(null);
    setSearchTerm("");
  };

  // Playbook Detail View
  if (viewMode === "playbook-detail" && selectedPlaybook) {
    return (
      <div className="container py-6 space-y-6 animate-fade-in">
        <button 
          onClick={handleBack}
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="h-4 w-4" strokeWidth={1.5} />
          Voltar
        </button>

        <div>
          <h1 className="font-display text-2xl font-semibold text-foreground">{selectedPlaybook.title}</h1>
          <p className="text-sm text-muted-foreground mt-1">{selectedPlaybook.description}</p>
        </div>

        <Card className="shadow-card">
          <CardContent className="p-0 divide-y divide-border">
            {selectedPlaybook.steps.map((step, index) => (
              <div key={index} className="flex items-center gap-4 p-4">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/10 text-xs font-medium text-primary">
                  {index + 1}
                </span>
                <span className="text-sm text-foreground">{step}</span>
              </div>
            ))}
          </CardContent>
        </Card>

        <Button 
          className="w-full h-12 text-base font-medium gradient-premium"
          onClick={() => {
            toast({
              title: "Playbook iniciado!",
              description: `${selectedPlaybook.title} está pronto para execução.`,
            });
          }}
        >
          <Play className="h-4 w-4 mr-2" strokeWidth={1.5} />
          Iniciar Playbook
        </Button>
      </div>
    );
  }

  // Specialty Detail View
  if (viewMode === "specialty-detail" && selectedSpecialty) {
    return (
      <div className="container py-6 space-y-6 animate-fade-in">
        <button 
          onClick={handleBack}
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="h-4 w-4" strokeWidth={1.5} />
          Voltar
        </button>

        <div>
          <h1 className="font-display text-2xl font-semibold text-foreground">{selectedSpecialty.title}</h1>
          <p className="text-sm text-muted-foreground mt-1">{selectedSpecialty.description}</p>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" strokeWidth={1.5} />
          <Input
            type="search"
            placeholder="Buscar prompt..."
            className="pl-10 bg-card border-border"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="space-y-2">
          {filteredPrompts.length > 0 ? (
            filteredPrompts.map((prompt) => (
              <Card key={prompt.id} className="shadow-card">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary font-medium">
                          {getCategoryLabel(prompt.category)}
                        </span>
                      </div>
                      <h3 className="text-sm font-medium text-foreground mb-1">{prompt.title}</h3>
                      <p className="text-xs text-muted-foreground line-clamp-2">{prompt.content}</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="shrink-0 h-8 w-8"
                      onClick={() => handleCopy(prompt.id, prompt.content)}
                    >
                      {copiedId === prompt.id ? (
                        <Check className="h-4 w-4 text-success" strokeWidth={1.5} />
                      ) : (
                        <Copy className="h-4 w-4 text-muted-foreground" strokeWidth={1.5} />
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card className="shadow-card">
              <CardContent className="p-8 text-center">
                <p className="text-sm text-muted-foreground">Nenhum prompt encontrado para esta especialidade</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    );
  }

  // Main List View
  return (
    <div className="container py-6 space-y-6 animate-fade-in">
      {/* Page Title */}
      <div>
        <h1 className="font-display text-2xl font-semibold text-foreground">Biblioteca</h1>
        <p className="text-sm text-muted-foreground mt-1">Prompts, playbooks e especialidades</p>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="prompts" className="w-full">
        <TabsList className="w-full grid grid-cols-3 h-auto p-1 bg-secondary">
          <TabsTrigger value="prompts" className="text-sm py-2">Prompts</TabsTrigger>
          <TabsTrigger value="playbooks" className="text-sm py-2">Playbooks</TabsTrigger>
          <TabsTrigger value="especialidades" className="text-sm py-2">Especialidades</TabsTrigger>
        </TabsList>

        {/* Prompts Tab */}
        <TabsContent value="prompts" className="mt-4 space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" strokeWidth={1.5} />
            <Input
              type="search"
              placeholder="Buscar prompt..."
              className="pl-10 bg-card border-border"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            {filteredPrompts.map((prompt) => (
              <Card key={prompt.id} className="shadow-card">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary font-medium">
                          {getCategoryLabel(prompt.category)}
                        </span>
                        {prompt.subcategory && (
                          <span className="text-xs text-muted-foreground">
                            {prompt.subcategory}
                          </span>
                        )}
                      </div>
                      <h3 className="text-sm font-medium text-foreground mb-1">{prompt.title}</h3>
                      <p className="text-xs text-muted-foreground line-clamp-2">{prompt.content}</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="shrink-0 h-8 w-8"
                      onClick={() => handleCopy(prompt.id, prompt.content)}
                    >
                      {copiedId === prompt.id ? (
                        <Check className="h-4 w-4 text-success" strokeWidth={1.5} />
                      ) : (
                        <Copy className="h-4 w-4 text-muted-foreground" strokeWidth={1.5} />
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Playbooks Tab */}
        <TabsContent value="playbooks" className="mt-4">
          <Card className="shadow-card">
            <CardContent className="p-0 divide-y divide-border">
              {playbooks.map((playbook) => (
                <button
                  key={playbook.id}
                  onClick={() => handlePlaybookClick(playbook)}
                  className="w-full flex items-center justify-between p-4 hover:bg-muted/50 transition-colors text-left"
                >
                  <div>
                    <h3 className="text-sm font-medium text-foreground">{playbook.title}</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {playbook.description} • {playbook.steps.length} etapas
                    </p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground" strokeWidth={1.5} />
                </button>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Specialties Tab */}
        <TabsContent value="especialidades" className="mt-4">
          <Card className="shadow-card">
            <CardContent className="p-0 divide-y divide-border">
              {specialties.map((specialty) => (
                <button
                  key={specialty.id}
                  onClick={() => handleSpecialtyClick(specialty)}
                  className="w-full flex items-center justify-between p-4 hover:bg-muted/50 transition-colors text-left"
                >
                  <div>
                    <h3 className="text-sm font-medium text-foreground">{specialty.title}</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {specialty.prompts} prompts disponíveis
                    </p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground" strokeWidth={1.5} />
                </button>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Biblioteca;
