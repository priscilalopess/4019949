import { Outlet } from "react-router-dom";
import TopHeader from "./TopHeader";
import BottomNav from "./BottomNav";

const AppLayout = () => {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <TopHeader />
      <main className="flex-1 mb-nav">
        <Outlet />
      </main>
      <BottomNav />
    </div>
  );
};

export default AppLayout;