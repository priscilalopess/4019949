import { Bell, User, FlaskConical } from "lucide-react";
import { Button } from "@/components/ui/button";

const TopHeader = () => {
  return (
    <header className="sticky top-0 z-50 w-full bg-card border-b border-border">
      <div className="container flex h-14 items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
            <FlaskConical className="h-5 w-5 text-primary-foreground" strokeWidth={1.5} />
          </div>
          <span className="font-display text-lg font-semibold text-foreground tracking-tight">
            ControllerLab
          </span>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
            <Bell className="h-5 w-5" strokeWidth={1.5} />
          </Button>
          <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
            <User className="h-5 w-5" strokeWidth={1.5} />
          </Button>
        </div>
      </div>
    </header>
  );
};

export default TopHeader;