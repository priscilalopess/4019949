import { NavLink, useLocation } from "react-router-dom";
import { Home, ListTodo, FileText, Library } from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { to: "/", icon: Home, label: "Home" },
  { to: "/rotinas", icon: ListTodo, label: "Rotinas" },
  { to: "/documentos", icon: FileText, label: "Docs" },
  { to: "/biblioteca", icon: Library, label: "Biblioteca" },
];

const BottomNav = () => {
  const location = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-nav border-t border-border pb-safe">
      <div className="flex h-16 items-center justify-around">
        {navItems.map(({ to, icon: Icon, label }) => {
          const isActive = location.pathname === to || 
            (to !== "/" && location.pathname.startsWith(to));
          
          return (
            <NavLink
              key={to}
              to={to}
              className={cn(
                "flex flex-col items-center justify-center gap-1 px-4 py-2 min-w-[4rem] rounded-lg transition-colors",
                isActive 
                  ? "text-nav-active" 
                  : "text-nav-foreground hover:text-foreground"
              )}
            >
              <Icon 
                className={cn(
                  "h-5 w-5 transition-all",
                  isActive && "scale-110"
                )} 
                strokeWidth={isActive ? 2 : 1.5} 
              />
              <span className={cn(
                "text-xs font-medium",
                isActive && "font-semibold"
              )}>
                {label}
              </span>
            </NavLink>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNav;