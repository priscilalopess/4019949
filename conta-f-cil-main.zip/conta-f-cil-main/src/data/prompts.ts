export interface Prompt {
  id: string;
  title: string;
  content: string;
  category: string;
  subcategory?: string;
}

export interface Role {
  id: string;
  title: string;
  description: string;
  icon: string;
}

export const roles: Role[] = [
  {
    id: "tributario",
    title: "Contador Tributário",
    description: "Especializado em planejamento tributário, legislação fiscal brasileira, regimes de tributação e estratégias de economia tributária lícita.",
    icon: "📊"
  },
  {
    id: "custos",
    title: "Contador de Custos",
    description: "Especialista em contabilidade de custos, análise de custos industriais, formação de preços e gestão de margem de contribuição.",
    icon: "💰"
  },
  {
    id: "auditor",
    title: "Auditor Contábil",
    description: "Experiente em auditoria interna e externa, análise de demonstrações financeiras e identificação de inconsistências contábeis.",
    icon: "🔍"
  },
  {
    id: "gerencial",
    title: "Contador Gerencial",
    description: "Focado em análise de indicadores financeiros, elaboração de relatórios gerenciais e suporte à tomada de decisão estratégica.",
    icon: "📈"
  },
  {
    id: "perito",
    title: "Perito Contábil",
    description: "Expertise em elaboração de laudos periciais, avaliação de empresas e análise de documentos contábeis para processos judiciais.",
    icon: "⚖️"
  },
  {
    id: "controller",
    title: "Controller",
    description: "Responsável por controles internos, planejamento financeiro, orçamento empresarial e análise de performance organizacional.",
    icon: "🎯"
  },
  {
    id: "consultor",
    title: "Contador Consultor",
    description: "Especializado em reestruturação empresarial, recuperação de créditos tributários e otimização de processos contábeis.",
    icon: "💡"
  },
  {
    id: "trabalhista",
    title: "Contador Trabalhista",
    description: "Especializado em departamento pessoal, folha de pagamento, obrigações trabalhistas e cálculos previdenciários.",
    icon: "👥"
  },
  {
    id: "fiscal",
    title: "Analista Fiscal",
    description: "Especializado em apuração de impostos, escrituração fiscal digital, compliance tributário e obrigações acessórias.",
    icon: "📋"
  },
  {
    id: "internacional",
    title: "Contador Internacional",
    description: "Expertise em normas internacionais de contabilidade (IFRS), operações de comércio exterior e tributação internacional.",
    icon: "🌎"
  },
  {
    id: "patrimonial",
    title: "Contador Patrimonial",
    description: "Especializado em controle patrimonial, inventários, depreciação de ativos e gestão de bens permanentes.",
    icon: "🏢"
  },
  {
    id: "terceiro-setor",
    title: "Contador de Terceiro Setor",
    description: "Especializado em organizações sem fins lucrativos, associações, fundações e ONGs.",
    icon: "🤝"
  },
  {
    id: "publico",
    title: "Contador Público",
    description: "Especializado em contabilidade pública, Lei de Responsabilidade Fiscal e demonstrações contábeis do setor público.",
    icon: "🏛️"
  },
  {
    id: "business-partner",
    title: "Business Partner Financeiro",
    description: "Parceiro estratégico das áreas de negócio, traduzindo dados contábeis em insights acionáveis para gestores.",
    icon: "🤝"
  },
  {
    id: "digital",
    title: "Contador Digital",
    description: "Especializado em transformação digital, automação de processos contábeis e implementação de ERPs.",
    icon: "💻"
  },
  {
    id: "investimentos",
    title: "Contador de Investimentos",
    description: "Especializado em mercado financeiro, fundos de investimento e tributação de aplicações financeiras.",
    icon: "📊"
  },
  {
    id: "imobiliario",
    title: "Contador Imobiliário",
    description: "Expertise em incorporações, contratos de construção, permuta de imóveis e tributação do setor imobiliário.",
    icon: "🏠"
  },
  {
    id: "mentor",
    title: "Mentor Contábil",
    description: "Orientação sobre desenvolvimento de carreira, gestão de escritório contábil e captação de clientes.",
    icon: "🎓"
  },
  {
    id: "agronegocio",
    title: "Contador Agronegócio",
    description: "Especializado em contabilidade rural, tributação agrícola, Funrural e operações do setor agropecuário.",
    icon: "🌾"
  },
  {
    id: "compliance",
    title: "Compliance Officer Contábil",
    description: "Focado em governança corporativa, prevenção à lavagem de dinheiro, controles internos e conformidade regulatória.",
    icon: "✅"
  }
];

export interface Category {
  id: string;
  title: string;
  description: string;
  icon: string;
  color: string;
  promptCount: number;
}

export const categories: Category[] = [
  {
    id: "contabil",
    title: "Setor Contábil",
    description: "Balancetes, DRE, relatórios gerenciais, auditoria e conciliações contábeis",
    icon: "📒",
    color: "primary",
    promptCount: 120
  },
  {
    id: "pessoal",
    title: "Departamento Pessoal",
    description: "Folha de pagamento, férias, rescisões, encargos trabalhistas e benefícios",
    icon: "👥",
    color: "info",
    promptCount: 80
  },
  {
    id: "fiscal",
    title: "Setor Fiscal",
    description: "Notas fiscais, ICMS, PIS/COFINS, SPED e obrigações acessórias",
    icon: "📋",
    color: "accent",
    promptCount: 100
  },
  {
    id: "financeiro",
    title: "Setor Financeiro",
    description: "Fluxo de caixa, análises financeiras, investimentos e gestão de riscos",
    icon: "💰",
    color: "success",
    promptCount: 90
  },
  {
    id: "estrategico",
    title: "Planejamento Estratégico",
    description: "Regimes tributários, reestruturação, projeções e tomada de decisão",
    icon: "🎯",
    color: "warning",
    promptCount: 60
  },
  {
    id: "comunicacao",
    title: "Comunicação",
    description: "E-mails, relatórios para clientes, apresentações e documentação",
    icon: "✉️",
    color: "secondary",
    promptCount: 50
  }
];

export const prompts: Prompt[] = [
  // Setor Contábil
  {
    id: "cont-1",
    title: "Análise de Balancetes",
    content: "Analise este balancete em PDF e identifique possíveis inconsistências contábeis, como erros de classificação de contas e divergências no ativo/passivo. Sugira ajustes para regularização.",
    category: "contabil",
    subcategory: "Análise"
  },
  {
    id: "cont-2",
    title: "Revisão de DRE",
    content: "Analise o Demonstrativo de Resultado do Exercício (DRE) enviado e identifique pontos de atenção, como variações incomuns nas despesas operacionais e lucros líquidos. Explique os principais fatores que podem estar impactando esses números e sugira melhorias para otimização financeira.",
    category: "contabil",
    subcategory: "Análise"
  },
  {
    id: "cont-3",
    title: "Comparação entre Períodos",
    content: "Compare os balancetes de [Insira período 1] e [Insira período 2] e identifique tendências, variações relevantes e possíveis erros contábeis. Apresente um resumo das principais mudanças e impactos financeiros.",
    category: "contabil",
    subcategory: "Análise"
  },
  {
    id: "cont-4",
    title: "Validação de Saldos",
    content: "Verifique se os saldos contábeis do balancete estão de acordo com os registros auxiliares, identificando possíveis divergências e inconsistências.",
    category: "contabil",
    subcategory: "Validação"
  },
  {
    id: "cont-5",
    title: "Identificação de Erros",
    content: "Revise este balancete e aponte possíveis erros, como lançamentos duplicados, omissões ou lançamentos em contas inadequadas. Sugira as devidas correções.",
    category: "contabil",
    subcategory: "Validação"
  },
  {
    id: "cont-6",
    title: "Relatório Gerencial",
    content: "Gere um relatório contábil gerencial com base nos dados fornecidos, destacando indicadores-chave de desempenho, rentabilidade e liquidez.",
    category: "contabil",
    subcategory: "Relatórios"
  },
  {
    id: "cont-7",
    title: "Análise de Indicadores",
    content: "Calcule e interprete os principais indicadores financeiros deste balanço, como margem de lucro, EBITDA, liquidez corrente e endividamento. Apresente insights acionáveis.",
    category: "contabil",
    subcategory: "Análise"
  },
  {
    id: "cont-8",
    title: "Relatório Comparativo",
    content: "Crie um relatório comparativo entre os balanços de [ano X] e [ano Y], destacando variações significativas e tendências relevantes.",
    category: "contabil",
    subcategory: "Relatórios"
  },
  {
    id: "cont-9",
    title: "Resumo Executivo",
    content: "Elabore um resumo executivo do relatório contábil fornecido, destacando os principais pontos de atenção e insights estratégicos.",
    category: "contabil",
    subcategory: "Relatórios"
  },
  {
    id: "cont-10",
    title: "Fluxo de Caixa",
    content: "Analise a Demonstração de Fluxo de Caixa fornecida e identifique padrões, gargalos financeiros e oportunidades de melhoria no fluxo de caixa da empresa.",
    category: "contabil",
    subcategory: "Análise"
  },
  {
    id: "cont-11",
    title: "Verificação de Conformidade",
    content: "Realize uma auditoria nos registros contábeis fornecidos para verificar sua conformidade com as normas contábeis e fiscais vigentes.",
    category: "contabil",
    subcategory: "Auditoria"
  },
  {
    id: "cont-12",
    title: "Rastreabilidade de Lançamentos",
    content: "Identifique a origem dos lançamentos contábeis e verifique sua coerência com os documentos fiscais e contábeis associados.",
    category: "contabil",
    subcategory: "Auditoria"
  },
  {
    id: "cont-13",
    title: "Detecção de Fraudes",
    content: "Analise as movimentações contábeis e identifique padrões incomuns ou indícios de fraudes financeiras.",
    category: "contabil",
    subcategory: "Auditoria"
  },
  {
    id: "cont-14",
    title: "Conciliação Bancária",
    content: "Realize a conciliação bancária entre os extratos bancários e os registros contábeis, identificando possíveis divergências e inconsistências.",
    category: "contabil",
    subcategory: "Conciliação"
  },
  {
    id: "cont-15",
    title: "Conciliação de Fornecedores",
    content: "Verifique a conciliação das contas a pagar com os registros dos fornecedores, identificando eventuais diferenças e propondo ajustes.",
    category: "contabil",
    subcategory: "Conciliação"
  },
  {
    id: "cont-16",
    title: "Conciliação de Clientes",
    content: "Analise a conciliação das contas a receber e identifique diferenças entre os registros contábeis e os valores registrados pelos clientes.",
    category: "contabil",
    subcategory: "Conciliação"
  },
  {
    id: "cont-17",
    title: "Conciliação Fiscal",
    content: "Verifique se os lançamentos contábeis estão de acordo com as obrigações fiscais e as declarações entregues ao fisco.",
    category: "contabil",
    subcategory: "Conciliação"
  },
  {
    id: "cont-18",
    title: "Revisão de Plano de Contas",
    content: "Analise o plano de contas da empresa e sugira melhorias para tornar a classificação contábil mais eficiente e padronizada.",
    category: "contabil",
    subcategory: "Estrutura"
  },
  {
    id: "cont-19",
    title: "Análise de Contingências",
    content: "Verifique riscos fiscais nos lançamentos contábeis e avalie a necessidade de provisões para contingências tributárias.",
    category: "contabil",
    subcategory: "Análise"
  },
  {
    id: "cont-20",
    title: "Auditoria de Estoques",
    content: "Verifique se os valores de estoque informados no balanço correspondem aos registros físicos e fiscais da empresa.",
    category: "contabil",
    subcategory: "Auditoria"
  },

  // Departamento Pessoal
  {
    id: "dp-1",
    title: "Cálculo de Folha",
    content: "Calcule a folha de pagamento considerando salário bruto, adicionais e descontos obrigatórios (INSS, FGTS, IRRF).",
    category: "pessoal",
    subcategory: "Folha"
  },
  {
    id: "dp-2",
    title: "Revisão de Folha",
    content: "Revise a folha de pagamento e verifique possíveis erros no cálculo dos encargos e benefícios.",
    category: "pessoal",
    subcategory: "Folha"
  },
  {
    id: "dp-3",
    title: "Análise de Rescisões",
    content: "Analise os cálculos de rescisão de contrato, garantindo a correta aplicação de saldo de salário, aviso prévio e FGTS.",
    category: "pessoal",
    subcategory: "Rescisão"
  },
  {
    id: "dp-4",
    title: "Cálculo de Férias",
    content: "Calcule o valor das férias de um funcionário, considerando o período aquisitivo e adicionais de pagamento.",
    category: "pessoal",
    subcategory: "Férias"
  },
  {
    id: "dp-5",
    title: "Encargos Trabalhistas",
    content: "Verifique os encargos trabalhistas aplicados na folha de pagamento e valide se os cálculos estão corretos.",
    category: "pessoal",
    subcategory: "Encargos"
  },
  {
    id: "dp-6",
    title: "Simulação de Contratação",
    content: "Simule o custo total da contratação de um novo funcionário, considerando salário, benefícios e encargos.",
    category: "pessoal",
    subcategory: "Contratação"
  },
  {
    id: "dp-7",
    title: "Cálculo de 13º Salário",
    content: "Calcule o 13º salário de um funcionário, considerando os descontos obrigatórios e a proporcionalidade.",
    category: "pessoal",
    subcategory: "13º Salário"
  },
  {
    id: "dp-8",
    title: "Benefícios e Descontos",
    content: "Verifique a concessão correta de benefícios e descontos na folha de pagamento, garantindo conformidade com as normas.",
    category: "pessoal",
    subcategory: "Benefícios"
  },
  {
    id: "dp-9",
    title: "Auditoria de Folha",
    content: "Realize uma auditoria na folha de pagamento e identifique possíveis falhas, como pagamentos indevidos.",
    category: "pessoal",
    subcategory: "Auditoria"
  },
  {
    id: "dp-10",
    title: "Registro de Ponto",
    content: "Valide o registro de ponto dos funcionários e identifique inconsistências relacionadas a horas extras e banco de horas.",
    category: "pessoal",
    subcategory: "Ponto"
  },
  {
    id: "dp-11",
    title: "Passivos Trabalhistas",
    content: "Analise os passivos trabalhistas e estime os riscos financeiros associados a possíveis ações judiciais.",
    category: "pessoal",
    subcategory: "Riscos"
  },
  {
    id: "dp-12",
    title: "Adicionais Noturnos",
    content: "Calcule os adicionais de insalubridade e periculosidade, verificando se os percentuais foram corretamente aplicados.",
    category: "pessoal",
    subcategory: "Adicionais"
  },
  {
    id: "dp-13",
    title: "Revisão de Contratos",
    content: "Reveja contratos de trabalho para garantir que estão em conformidade com as normas trabalhistas atuais.",
    category: "pessoal",
    subcategory: "Contratos"
  },
  {
    id: "dp-14",
    title: "Planejamento de Pessoal",
    content: "Analise o planejamento de pessoal e simule cenários de novas contratações e demissões.",
    category: "pessoal",
    subcategory: "Planejamento"
  },
  {
    id: "dp-15",
    title: "Licenças e Afastamentos",
    content: "Verifique registros de licenças e afastamentos e calcule o impacto na folha de pagamento.",
    category: "pessoal",
    subcategory: "Afastamentos"
  },

  // Setor Fiscal
  {
    id: "fisc-1",
    title: "Revisão de Notas Fiscais",
    content: "Analise as notas fiscais enviadas em formato PDF e verifique se há erros de preenchimento, divergências de valores ou falta de retenções obrigatórias. Aponte possíveis correções.",
    category: "fiscal",
    subcategory: "Notas Fiscais"
  },
  {
    id: "fisc-2",
    title: "Comparação de NFs",
    content: "Compare as notas fiscais de entrada e saída para identificar possíveis inconsistências fiscais, como erros de alíquotas, CFOP e cálculos incorretos.",
    category: "fiscal",
    subcategory: "Notas Fiscais"
  },
  {
    id: "fisc-3",
    title: "Conferência de ICMS",
    content: "Verifique a correta aplicação das alíquotas de ICMS, PIS e COFINS nas notas fiscais anexadas. Identifique possíveis valores pagos a maior ou a menor e sugira ajustes.",
    category: "fiscal",
    subcategory: "ICMS"
  },
  {
    id: "fisc-4",
    title: "Auditoria ICMS-ST",
    content: "Faça uma auditoria nos cálculos do ICMS-ST e PIS/COFINS monofásico nas notas fiscais anexadas. Apresente um relatório com eventuais diferenças encontradas.",
    category: "fiscal",
    subcategory: "ICMS-ST"
  },
  {
    id: "fisc-5",
    title: "Simulação de Regimes",
    content: "Analise o perfil da empresa e simule os impactos tributários na escolha entre Lucro Real, Lucro Presumido e Simples Nacional. Apresente um comparativo de tributos.",
    category: "fiscal",
    subcategory: "Regimes"
  },
  {
    id: "fisc-6",
    title: "Escolha de Regime",
    content: "Com base no faturamento e na atividade da empresa, determine qual regime tributário seria mais vantajoso considerando a menor carga tributária e conformidade fiscal.",
    category: "fiscal",
    subcategory: "Regimes"
  },
  {
    id: "fisc-7",
    title: "Apuração de Impostos",
    content: "Realize o cálculo da apuração do ICMS, PIS e COFINS conforme os documentos anexados. Identifique eventuais diferenças ou créditos a serem aproveitados.",
    category: "fiscal",
    subcategory: "Apuração"
  },
  {
    id: "fisc-8",
    title: "Compensação de Créditos",
    content: "Verifique a correta compensação de créditos tributários na apuração dos impostos federais e estaduais anexados. Aponte possíveis riscos fiscais.",
    category: "fiscal",
    subcategory: "Créditos"
  },
  {
    id: "fisc-9",
    title: "Obrigações Acessórias",
    content: "Revise as obrigações acessórias enviadas (SPED Fiscal, EFD-Contribuições, DCTF, etc.) e verifique se há inconsistências ou divergências com os dados contábeis.",
    category: "fiscal",
    subcategory: "SPED"
  },
  {
    id: "fisc-10",
    title: "Conformidade SPED",
    content: "Confira a conformidade dos arquivos enviados para o SPED Fiscal e EFD-Contribuições. Aponte erros de preenchimento e possíveis ajustes para evitar penalidades.",
    category: "fiscal",
    subcategory: "SPED"
  },
  {
    id: "fisc-11",
    title: "Créditos Tributários",
    content: "Analise notas fiscais de entrada para garantir que todos os créditos tributários possíveis foram aproveitados.",
    category: "fiscal",
    subcategory: "Créditos"
  },
  {
    id: "fisc-12",
    title: "NFs Canceladas",
    content: "Verifique se há notas fiscais canceladas sem justificativa e os impactos fiscais.",
    category: "fiscal",
    subcategory: "Notas Fiscais"
  },
  {
    id: "fisc-13",
    title: "Códigos Fiscais",
    content: "Analise se houve erro no preenchimento dos códigos fiscais (CFOP, CST, NCM) nas notas fiscais.",
    category: "fiscal",
    subcategory: "Códigos"
  },
  {
    id: "fisc-14",
    title: "Simples Nacional",
    content: "Verifique se a empresa está emitindo corretamente notas fiscais para clientes do Simples Nacional.",
    category: "fiscal",
    subcategory: "Simples"
  },
  {
    id: "fisc-15",
    title: "Operações Interestaduais",
    content: "Analise a correta aplicação da alíquota de ICMS nas operações internas e interestaduais.",
    category: "fiscal",
    subcategory: "ICMS"
  },

  // Setor Financeiro
  {
    id: "fin-1",
    title: "Análise de Fluxo de Caixa",
    content: "Examine a eficiência do capital de giro da empresa, analisando o ciclo financeiro e sugerindo melhorias para otimização do fluxo de caixa.",
    category: "financeiro",
    subcategory: "Fluxo de Caixa"
  },
  {
    id: "fin-2",
    title: "Gestão de Riscos",
    content: "Identifique os principais riscos financeiros enfrentados pela empresa e sugira estratégias de mitigação.",
    category: "financeiro",
    subcategory: "Riscos"
  },
  {
    id: "fin-3",
    title: "Estudo de Viabilidade",
    content: "Analise os impactos financeiros e tributários de novos investimentos para garantir decisões estratégicas seguras.",
    category: "financeiro",
    subcategory: "Investimentos"
  },
  {
    id: "fin-4",
    title: "Capital de Giro",
    content: "Examine a eficiência do capital de giro da empresa, analisando o ciclo financeiro e sugerindo melhorias para otimização do fluxo de caixa.",
    category: "financeiro",
    subcategory: "Capital"
  },
  {
    id: "fin-5",
    title: "Relatório de Endividamento",
    content: "Analise a estrutura da dívida da empresa e sugira estratégias para reduzir riscos financeiros.",
    category: "financeiro",
    subcategory: "Dívidas"
  },
  {
    id: "fin-6",
    title: "Análise de Sazonalidade",
    content: "Identifique padrões sazonais nas receitas e despesas para ajudar na previsão de fluxo de caixa e planejamento financeiro.",
    category: "financeiro",
    subcategory: "Análise"
  },
  {
    id: "fin-7",
    title: "Ponto de Equilíbrio",
    content: "Calcule o ponto de equilíbrio da empresa e analise estratégias para otimizar custos e aumentar a lucratividade.",
    category: "financeiro",
    subcategory: "Análise"
  },
  {
    id: "fin-8",
    title: "Rentabilidade por Produto",
    content: "Calcule a lucratividade de cada produto e identifique quais itens estão impactando positivamente ou negativamente o resultado financeiro.",
    category: "financeiro",
    subcategory: "Rentabilidade"
  },
  {
    id: "fin-9",
    title: "Eficiência Operacional",
    content: "Analise os custos operacionais e identifique oportunidades para melhorar a eficiência e reduzir desperdícios.",
    category: "financeiro",
    subcategory: "Eficiência"
  },
  {
    id: "fin-10",
    title: "Projeção de Crescimento",
    content: "Projete cenários de crescimento da empresa com base nos demonstrativos financeiros e nas tendências de mercado.",
    category: "financeiro",
    subcategory: "Projeções"
  },

  // Planejamento Estratégico
  {
    id: "est-1",
    title: "Comparação Lucro Real x Presumido",
    content: "Simule a tributação da empresa nos regimes de Lucro Real e Lucro Presumido para identificar a opção mais vantajosa.",
    category: "estrategico",
    subcategory: "Regimes"
  },
  {
    id: "est-2",
    title: "Planejamento Tributário",
    content: "Analise a carga tributária da empresa e sugira estratégias para otimização fiscal dentro da legalidade.",
    category: "estrategico",
    subcategory: "Tributação"
  },
  {
    id: "est-3",
    title: "Reestruturação Empresarial",
    content: "Analise a estrutura societária atual e proponha melhorias para otimização tributária e operacional.",
    category: "estrategico",
    subcategory: "Estrutura"
  },
  {
    id: "est-4",
    title: "Benefícios Fiscais",
    content: "Analise se a empresa está aproveitando corretamente os incentivos fiscais disponíveis e sugira melhorias para otimização tributária.",
    category: "estrategico",
    subcategory: "Incentivos"
  },
  {
    id: "est-5",
    title: "Impacto de Legislação",
    content: "Analise como mudanças recentes na legislação tributária podem afetar os resultados financeiros da empresa.",
    category: "estrategico",
    subcategory: "Legislação"
  },

  // Comunicação
  {
    id: "com-1",
    title: "E-mail para Cliente",
    content: "Elabore um e-mail profissional para o cliente explicando [situação específica] de forma clara e objetiva.",
    category: "comunicacao",
    subcategory: "E-mails"
  },
  {
    id: "com-2",
    title: "Relatório Executivo",
    content: "Crie um relatório executivo resumido para apresentação aos sócios/diretores, destacando os principais indicadores e pontos de atenção.",
    category: "comunicacao",
    subcategory: "Relatórios"
  },
  {
    id: "com-3",
    title: "Apresentação de Resultados",
    content: "Elabore uma apresentação dos resultados financeiros do período para reunião com a diretoria.",
    category: "comunicacao",
    subcategory: "Apresentações"
  },
  {
    id: "com-4",
    title: "Parecer Técnico",
    content: "Elabore um parecer técnico sobre [tema específico] fundamentado na legislação vigente.",
    category: "comunicacao",
    subcategory: "Pareceres"
  },
  {
    id: "com-5",
    title: "Carta de Orientação",
    content: "Elabore uma carta de orientação ao cliente sobre procedimentos necessários para [situação específica].",
    category: "comunicacao",
    subcategory: "Cartas"
  }
];
